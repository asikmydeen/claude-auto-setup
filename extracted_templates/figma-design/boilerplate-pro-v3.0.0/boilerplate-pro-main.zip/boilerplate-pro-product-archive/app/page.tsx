// eslint-disable
import { getSession } from '@/app/supabase-server';
import { FooterWebsite } from '@/components/footer/FooterWebsite';
import Faq from '@/components/landing/faq';
import FeatureOne from '@/components/landing/feature-one';
import FeatureThree from '@/components/landing/feature-three';
import FeatureTwo from '@/components/landing/feature-two';
import FeaturesList from '@/components/landing/features-list';
import FirstSection from '@/components/landing/first-section';
import Hero from '@/components/landing/hero';
import Newsletter from '@/components/landing/newsletter';
import SecondSection from '@/components/landing/second-section';
import NavbarFixed from '@/components/navbar/NavbarFixed';

export default async function PricingPage() {
  const [session] = await Promise.all([getSession()]).then();

  return (
    <>
      <NavbarFixed session={session} />
      <div className="text-neutral-200 relative flex h-full min-h-screen flex-col items-center overflow-hidden">
        <div className="relative flex w-full flex-col items-center justify-center pb-0 md:pb-[80px]">
          <Hero />
          <FeaturesList />
          <FirstSection />
          <SecondSection />
          <FeatureOne />
          <FeatureTwo />
          <FeatureThree />
          <Faq />
          <Newsletter />
        </div>
        <FooterWebsite />
      </div>
    </>
  );
}
