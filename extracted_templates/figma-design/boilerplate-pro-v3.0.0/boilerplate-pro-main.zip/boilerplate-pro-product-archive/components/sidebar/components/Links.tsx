'use client';

/* eslint-disable */
import NavLink from '@/components/link/NavLink';
import { IRoute } from '@/types/types';
import { Database } from '@/types_db';
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel
} from '@chakra-ui/accordion';
import { usePathname, useRouter } from 'next/navigation';
import { PropsWithChildren, useCallback, useState } from 'react';
import { FaCircle } from 'react-icons/fa';
import { IoMdAdd } from 'react-icons/io';

interface SidebarLinksProps extends PropsWithChildren {
  routes: IRoute[];
  [x: string]: any;
}

export function SidebarLinks(props: SidebarLinksProps) {
  const pathname = usePathname();

  const { routes, onOpen } = props;

  // verifies if routeName is the one active (in browser input)
  const activeRoute = useCallback(
    (routeName: string) => {
      return pathname?.includes(routeName);
    },
    [pathname]
  );
  const activeLayout = useCallback(
    (routeName: string) => {
      console.log(pathname);
      return pathname?.includes('/ai');
    },
    [pathname]
  );

  // this function creates the links and collapses that appear in the sidebar (left menu)
  const createLinks = (routes: IRoute[]) => {
    const router = useRouter();
    return routes.map((route, key) => {
      if (route.collapse && !route.invisible) {
        return (
          <Accordion allowToggle key={key}>
            <AccordionItem border="none" mb="14px" key={key}>
              <AccordionButton
                display="flex"
                alignItems="center"
                mb="4px"
                justifyContent="center"
                _hover={{
                  bg: 'unset'
                }}
                _focus={{
                  boxShadow: 'none'
                }}
                borderRadius="8px"
                w="100%"
                pb="10px"
                ms={0}
              >
                {route.icon ? (
                  <div className="flex w-full max-w-full items-center justify-between pl-8 pr-7">
                    <div className="flex w-full items-center justify-center">
                      <div
                        className={`text mr-3 mt-1.5 ${
                          activeLayout(route.path.toLowerCase())
                            ? 'text-brand-500  dark:text-white'
                            : 'text-gray-500 dark:text-white'
                        } `}
                      >
                        {route.icon}
                      </div>
                      <p
                        className={`mr-auto text-sm font-medium ${
                          activeLayout(route.path.toLowerCase())
                            ? 'font-bold text-navy-800 dark:text-white'
                            : 'font-medium text-gray-500 dark:text-gray-400'
                        }`}
                      >
                        {route.name}
                      </p>
                    </div>
                    <AccordionIcon ms="auto" color={'gray.400'} />
                  </div>
                ) : (
                  <div className="flex w-full items-center pb-2.5 pl-8 pt-0">
                    <p
                      className={`mr-auto text-sm font-medium ${
                        activeRoute(route.path.toLowerCase())
                          ? 'text-navy-800 dark:text-white'
                          : 'text-gray-500 dark:text-gray-400'
                      }`}
                    >
                      {route.name}
                    </p>
                    <AccordionIcon ms="auto" color={'gray.400'} />
                  </div>
                )}
              </AccordionButton>
              <AccordionPanel py="0px" ps={'32px'}>
                <ul>
                  {
                    route.icon && route.items
                      ? createLinks(route.items) // for bullet accordion links
                      : route.items
                      ? createAccordionLinks(route.items)
                      : '' // for non-bullet accordion links
                  }
                </ul>
              </AccordionPanel>
            </AccordionItem>
          </Accordion>
        );
      } else if (!route.invisible) {
        return (
          <div key={key}>
            {route.icon ? (
              <div className="mb-6 flex w-full max-w-full items-center justify-between pl-8">
                {route.path.includes('premium') && !props.subscription ? (
                  <div className="flex w-full">
                    <div
                      className="w-full cursor-pointer"
                      onClick={() => onOpen()}
                    >
                      <div className="flex w-[98%] max-w-[98%] items-center justify-center">
                        <div className="flex w-full items-center justify-center">
                          <div
                            className={`text mr-3 mt-1.5 ${
                              activeRoute(route.path.toLowerCase())
                                ? 'text-brand-500 dark:text-white'
                                : 'text-gray-500 dark:text-white'
                            } `}
                          >
                            {route.icon}
                          </div>
                          <p
                            className={`mr-auto text-sm ${
                              activeRoute(route.path.toLowerCase())
                                ? 'font-bold text-navy-800 dark:text-white'
                                : 'font-medium text-gray-500 dark:text-gray-400'
                            }`}
                          >
                            {route.name}
                          </p>
                        </div>
                        {route.rightElement ? (
                          <div className="ml-auto mr-2.5 h-[34px] w-[34px] items-center justify-center rounded-full border-[1px] border-gray-200 text-navy-800 dark:border-white/30  ">
                            <IoMdAdd className="h-5 w-5 text-inherit" />
                          </div>
                        ) : null}
                        <div className="flex rounded-[25px] bg-brand-500 bg-opacity-20 px-2 py-0.5 text-sm font-bold text-brand-500 dark:bg-brand-400 lg:hidden xl:flex">
                          PRO
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <NavLink
                    href={route.layout ? route.layout + route.path : route.path}
                    key={key}
                    styles={{ width: '100%' }}
                  >
                    <div className="w-full items-center justify-center">
                      <div className="flex w-full items-center justify-center">
                        <div
                          className={`text mr-3 mt-1.5 ${
                            activeRoute(route.path.toLowerCase())
                              ? 'text-brand-500 dark:text-white'
                              : 'text-gray-500 dark:text-white'
                          } `}
                        >
                          {route.icon}
                        </div>
                        <p
                          className={`mr-auto text-sm ${
                            activeRoute(route.path.toLowerCase())
                              ? 'font-bold text-navy-800 dark:text-white'
                              : 'font-medium text-gray-500 dark:text-gray-400'
                          }`}
                        >
                          {route.name}
                        </p>
                      </div>
                      {route.rightElement ? (
                        <div className="ml-auto mr-2.5 h-[34px] w-[34px] items-center justify-center rounded-full border-[1px] border-gray-200 text-navy-800 dark:border-white/30 dark:text-white">
                          <IoMdAdd className="h-5 w-5 text-inherit" />
                        </div>
                      ) : null}
                    </div>
                  </NavLink>
                )}
              </div>
            ) : (
              <li className="ml-0">
                <div className="mb-2 items-center pl-8">
                  <NavLink
                    href={route.layout ? route.layout + route.path : route.path}
                    key={key}
                  >
                    <p
                      className={`text-xs ${
                        activeRoute(route.path.toLowerCase())
                          ? 'font-bold text-navy-800 dark:text-white'
                          : 'font-medium text-gray-500 dark:text-white'
                      }`}
                    >
                      {route.name}
                    </p>
                  </NavLink>
                </div>
              </li>
            )}
          </div>
        );
      }
    });
  };
  // this function creates the links from the secondary accordions (for example auth -> sign-in -> default)
  const createAccordionLinks = (routes: IRoute[]) => {
    return routes.map((route: IRoute, key: number) => {
      return (
        <li className="mb-2.5 ml-[28px] flex max-w-full items-center" key={key}>
          <NavLink href={route.layout + route.path} key={key}>
            <FaCircle className="mr-2 h-1.5 w-1.5 text-brand-500 dark:text-white" />
            <p
              className={`text-xs ${
                activeRoute(route.path.toLowerCase()) ? 'font-bold' : ''
              } ${
                activeRoute(route.path.toLowerCase())
                  ? 'text-navy-800 dark:text-white'
                  : 'text-gray-500 dark:text-white'
              }`}
            >
              {route.name}
            </p>
          </NavLink>
        </li>
      );
    });
  };
  //  BRAND
  return <>{createLinks(routes)}</>;
}

export default SidebarLinks;
