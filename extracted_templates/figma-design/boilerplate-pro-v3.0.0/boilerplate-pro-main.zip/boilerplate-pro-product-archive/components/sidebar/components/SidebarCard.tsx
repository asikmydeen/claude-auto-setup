'use client';

import SidebarImage from '@/public/SidebarBadge.png';
import { Database } from '@/types_db';
import Image from 'next/image';
import { MdChevronRight } from 'react-icons/md';

type Price = Database['public']['Tables']['prices']['Row'];
interface SidebarCard {
  [x: string]: any;
}
export default function SidebarDocs(props: SidebarCard) {
  if (props.subscription) {
    return (
      // <div className="relative flex w-[calc(100%_-_10px)] items-center rounded-[16px] border-[1px] border-gray-200 px-[14px] py-4 dark:border-white/20">
      <div className="relative flex w-[256px] items-center rounded-[16px] border-[1px] border-gray-200 px-[14px] py-4 dark:border-white/20">
        <Image
          width="54"
          height="30"
          className="mr-2.5 w-[27px]"
          src={SidebarImage.src}
          alt=""
        />
        <div className="flex w-full flex-col justify-center">
          <p className="mb-0.5 text-sm font-bold text-navy-800 dark:text-white">
            PRO Member
          </p>
          <p className="text-sm font-medium text-gray-500">
            Unlimited plan active
          </p>
        </div>
      </div>
    );
  } else {
    return (
      <div className="relative ml-2.5 mr-1 flex w-[256px] flex-col items-center rounded-[16px] border-[1px] border-gray-200 px-[14px] py-4 dark:border-white/10">
        <Image
          width="54"
          height="30"
          className="w-[54px]"
          src={SidebarImage.src}
          alt=""
        />
        <div className="mb-3 flex w-full flex-col pt-4">
          <p className="mb-2.5 text-center text-lg font-bold text-navy-800 dark:text-white">
            Upgrade to Unlimited
          </p>
          <p className="text-center text-sm font-medium text-gray-500 dark:text-gray-400 focus:dark:!bg-white/20 active:dark:!bg-white/20">
            Generate premium Essays by upgrading to an unlimited plan!
          </p>
        </div>
        <button
          className="mt-3 flex w-full items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] "
          onClick={() => {
            props.onOpen();
          }}
        >
          Go unlimited for just $9
          <MdChevronRight className="mt-0.5 h-4 w-4" />
        </button>
        <p className="mb-1 mt-4 text-center text-xs font-semibold text-gray-500 dark:text-gray-400">
          Join 80,000+ customers now
        </p>
      </div>
    );
  }
}
