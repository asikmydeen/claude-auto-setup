'use client';

import logo from '/public/logo-horizon-boilerplate.png';
import Card from '@/components/card';
import { useDisclosure } from '@chakra-ui/hooks';
import {
  renderThumb,
  renderTrack,
  renderView
} from '@/components/scrollbar/Scrollbar';
import Links from '@/components/sidebar/components/Links';
import SidebarCard from '@/components/sidebar/components/SidebarCard';
import modalImage from '@/public/Modal.png';
import { IRoute } from '@/types/types';
import { Database } from '@/types_db';
import {
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay
} from '@chakra-ui/modal';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import React, { PropsWithChildren, useContext } from 'react';
import { useState } from 'react';
import { Scrollbars } from 'react-custom-scrollbars-2';
import { FiLogOut } from 'react-icons/fi';
import { HiX } from 'react-icons/hi';
import { IoIosStar } from 'react-icons/io';
import { MdCheckCircle, MdChevronRight } from 'react-icons/md';
import { getRedirectMethod } from '@/utils/auth-helpers/settings';
import {
  PlanContext,
  ProductsContext,
  UserContext,
  UserDetailsContext
} from '@/contexts/layout';
import { getErrorRedirect } from '@/utils/helpers';
import { getStripe } from '@/utils/stripe/client';
import { checkoutWithStripe } from '@/utils/stripe/server';
import { handleRequest } from '@/utils/auth-helpers/client';
import { SignOut } from '@/utils/auth-helpers/server';
import Link from 'next/link';

export interface SidebarProps extends PropsWithChildren {
  routes: IRoute[];
  [x: string]: any;
}
interface SidebarLinksProps extends PropsWithChildren {
  routes: IRoute[];
  [x: string]: any;
}

type Price = Database['public']['Tables']['prices']['Row'];

function Sidebar(props: SidebarProps) {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const router = getRedirectMethod() === 'client' ? useRouter() : null;
  const { routes } = props;
  const user = useContext(UserContext);
  const userDetails = useContext(UserDetailsContext);
  const [priceIdLoading, setPriceIdLoading] = useState<string>();
  const { plan, setPlan } = useContext(PlanContext);
  const products = useContext(ProductsContext);
  const currentPath = usePathname();

  const handleCheckout = async (price: Price) => {
    setPriceIdLoading(price.id);

    if (!user) {
      setPriceIdLoading(undefined);
      return router.push('/dashboard/signin/signup');
    }

    const { errorRedirect, sessionId } = await checkoutWithStripe(
      price,
      currentPath
    );

    if (errorRedirect) {
      setPriceIdLoading(undefined);
      return router.push(errorRedirect);
    }

    if (!sessionId) {
      setPriceIdLoading(undefined);
      return router.push(
        getErrorRedirect(
          currentPath,
          'An unknown error occurred.',
          'Please try again later or contact a system administrator.'
        )
      );
    }

    const stripe = await getStripe();
    stripe?.redirectToCheckout({ sessionId });

    setPriceIdLoading(undefined);
  };

  // SIDEBAR
  return (
    <div
      className={`lg:!z-99 fixed !z-[99] min-h-full w-[285px] transition-all md:!z-[99] xl:!z-0 ${
        props.variant === 'auth' ? 'xl:hidden' : 'xl:block'
      } ${props.open ? '' : '-translate-x-[110%] xl:translate-x-[unset]'}`}
    >
      <Card
        extra={`ml-3 w-full h-[96.5vh] sm:mr-4 md:mr-[-50px] sm:my-4 m-7 !rounded-[20px] overflow-hidden`}
      >
        <Modal isOpen={isOpen} onClose={onClose}>
          <ModalOverlay bg="rgba(0, 0, 0, 0.85)" />
          <ModalContent
            zIndex={'100'}
            mx="auto"
            mt="120px"
            bg="transparent"
            boxShadow="unset"
            maxW="unset"
            w="unset"
            display={'flex'}
            justifyContent="center"
            alignItems="center"
          >
            <ModalBody p="0px">
              <div className="z-[100] flex">
                <Image
                  width="340"
                  height="681"
                  src={modalImage.src}
                  className="z-[100] hidden w-[340px] rounded-l-[16px] md:block"
                  alt="avatar"
                />
                <div className="flex flex-col rounded-l-2xl rounded-r-2xl bg-white px-[30px] py-[34px] dark:!bg-navy-800 md:w-[412px] md:min-w-[412px] md:rounded-l-[0px] md:px-[42px] lg:w-[456px] lg:min-w-[456px]">
                  <p className="mb-3 text-[26px]  font-extrabold text-navy-800 dark:text-white">
                    Upgrade to Unlimited
                  </p>
                  <p className="mb-6 font-medium text-gray-500 dark:text-gray-400">
                    Join 80,000+ customers now
                  </p>
                  {/* Features */}
                  <div className="flex w-full flex-col xl:w-[80%]">
                    <div className="mb-5 flex items-center">
                      <MdCheckCircle className="mr-2.5 h-[20px] w-[20px] text-green-500" />
                      <span className="text-sm font-medium text-navy-800 dark:text-white">
                        Access to 12+ Essay types
                      </span>
                    </div>
                    <div className="mb-5 flex items-center">
                      <MdCheckCircle className="mr-2.5 h-[20px] w-[20px] text-green-500" />
                      <span className="text-sm font-medium text-navy-800 dark:text-white">
                        Up to 1500 words per Essay
                      </span>
                    </div>
                    <div className="mb-5 flex items-center">
                      <MdCheckCircle className="mr-2.5 h-[20px] w-[20px] text-green-500" />
                      <span className="text-sm font-medium text-navy-800 dark:text-white">
                        Academic Citation formats (APA, etc.)
                      </span>
                    </div>
                    <div className="mb-5 flex items-center">
                      <MdCheckCircle className="mr-2.5 h-[20px] w-[20px] text-green-500" />
                      <span className="text-sm font-medium text-navy-800 dark:text-white">
                        Academic Levels (Master, etc.)
                      </span>
                    </div>
                    <div className="mb-6 flex items-center">
                      <MdCheckCircle className="mr-2.5 h-[20px] w-[20px] text-green-500" />
                      <span className="text-sm font-medium text-navy-800 dark:text-white">
                        Essay Tones (Academic, etc.)
                      </span>
                    </div>
                  </div>
                  {/* YEARLY */}
                  <div
                    className={`relative flex items-center border-[1px] duration-[0.15s] ${
                      plan.product === 'prod_**************'
                        ? 'border-brand-500 dark:border-white'
                        : 'border-gray-200 dark:border-white/30'
                    } mb-5 w-full cursor-pointer rounded-[10px] px-[14px] py-[14px]`}
                    onClick={() =>
                      setPlan({
                        product: 'prod_**************',
                        price: 'price_************************'
                      })
                    }
                  >
                    <p className="mb-0.5 ml-2 mr-2 text-sm font-bold text-navy-800 dark:text-white">
                      Yearly
                    </p>
                    <div className="flex rounded-[4px] bg-green-500 bg-opacity-20 px-2 py-0.5 text-sm font-bold text-green-500 lg:hidden xl:flex">
                      Save 35%
                    </div>
                    <p className="ml-auto flex font-medium text-navy-800 dark:text-white">
                      $69
                      <span className="ml-1 mt-0.5 text-sm font-medium text-gray-500 dark:text-gray-400">
                        /year
                      </span>
                    </p>
                  </div>
                  {/* END YEARLY */}
                  {/* MONTHLY */}
                  <div
                    className={`relative flex items-center border-[1px] duration-[0.15s] ${
                      plan.product === 'prod_**************'
                        ? 'border-brand-500 dark:border-white'
                        : 'border-gray-200 dark:border-white/30'
                    } mb-7 w-full cursor-pointer rounded-[10px] px-[14px] py-[14px]`}
                    onClick={() =>
                      setPlan({
                        product: 'prod_**************',
                        price: 'price_************************'
                      })
                    }
                  >
                    <p className="mb-0.5 ml-2 mr-2 text-sm font-bold text-navy-800 dark:text-white">
                      Monthly
                    </p>
                    <p className="ml-auto flex font-medium text-navy-800 dark:text-white">
                      $9
                      <span className="ml-1 mt-0.5 text-sm font-medium text-gray-500 dark:text-gray-400">
                        /month
                      </span>
                    </p>
                  </div>
                  {/* END MONTHLY */}
                  {products.map((product: any, key: number) => {
                    const price = product?.prices?.find(
                      (price: any) => price.id === plan.price
                    );
                    if (product.id === plan.product) {
                      if (!price) return null;
                      return (
                        <button
                          key={key}
                          className="mb-7 flex w-full items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] "
                          onClick={() => handleCheckout(price)}
                        >
                          Upgrade now
                          <MdChevronRight className="mt-0.5 h-4 w-4" />
                        </button>
                      );
                    }
                  })}
                  <p className="mx-auto mb-[5px] text-xs font-semibold text-gray-500 dark:text-gray-400">
                    Used by 80,000+ customers monthly
                  </p>
                  <div className="mx-auto flex flex-row items-center">
                    <IoIosStar className="mr-[1px] h-4 w-4 text-orange-500" />
                    <IoIosStar className="mr-[1px] h-4 w-4 text-orange-500" />
                    <IoIosStar className="mr-[1px] h-4 w-4 text-orange-500" />
                    <IoIosStar className="mr-[1px] h-4 w-4 text-orange-500" />
                    <IoIosStar className="mr-1.5 h-4 w-4 text-orange-500" />
                    <p className="h-full text-sm  font-extrabold text-navy-800 dark:text-white">
                      4.9
                    </p>
                  </div>
                </div>
              </div>
            </ModalBody>
            <ModalCloseButton
              position={'absolute'}
              right="20px"
              top="20px"
              borderRadius="full"
              className="text-[#120F43]  "
              bg="transparent !important"
              _hover={{ bg: 'transparent !important' }}
              _focus={{ bg: 'transparent !important' }}
              _active={{ bg: 'transparent !important' }}
              zIndex="99"
            />
          </ModalContent>
        </Modal>
        <Scrollbars
          universal={true}
          autoHide
          renderTrackVertical={renderTrack}
          renderThumbVertical={renderThumb}
          renderView={renderView}
        >
          <div className="flex h-full flex-col justify-between">
            <div>
              <span
                className="absolute right-4 top-4 block cursor-pointer text-gray-200 dark:text-white/40 xl:hidden"
                onClick={() => props.setOpen(false)}
              >
                <HiX />
              </span>
              <div className={`mt-8 flex items-center justify-center`}>
                <Image
                  width="38"
                  height="38"
                  alt="Horizon UI Boilerplate logo"
                  src={logo.src}
                />
                <h5 className="ms-2 text-base font-extrabold leading-5 text-navy-900 dark:text-white">
                  Horizon UI Boilerplate
                </h5>
              </div>
              <div className="mb-8 mt-8 h-px bg-gray-200 dark:bg-white/10" />
              {/* Nav item */}
              <ul>
                <Links routes={routes} onOpen={onOpen} />
              </ul>
            </div>
            {/* Free Horizon Card    */}
            <div className="mb-[30px] mt-[28px]">
              <div className="flex justify-center pr-2.5">
                <SidebarCard onOpen={onOpen} />
              </div>
              {/* Sidebar profile info */}
              <div className="ml-3 mt-5 flex max-w-[256px] items-center pb-10 pr-2 md:pb-0">
                <Link href="/dashboard/settings">
                  <div className="relative h-8 w-8 rounded-full bg-blue-200">
                    <Image
                      width="32"
                      height="32"
                      src={
                        userDetails?.user_metadata.avatar_url
                          ? userDetails?.user_metadata.avatar_url
                          : 'https://lh3.googleusercontent.com/a/ACg8ocI5LR8r-XbnmYsQ3hq0a_L534cv4P_PTSHQBRQ36zRaTQ=s96-c'
                      }
                      className="h-full w-full rounded-full"
                      alt="avatar"
                    />
                  </div>
                </Link>
                <Link href="/dashboard/settings">
                  <p className="ml-2 mr-3 flex items-center text-xs font-bold leading-none text-navy-900 dark:text-white">
                    {userDetails?.user_metadata.full_name
                      ? userDetails?.user_metadata.full_name
                      : 'User'}
                  </p>
                </Link>
                <form
                  className="w-full"
                  onSubmit={(e) => handleRequest(e, SignOut, router)}
                >
                  <button
                    className="ml-auto flex h-[32px] w-[32px] cursor-pointer items-center justify-center rounded-full border-[1px] border-gray-200 bg-transparent text-center text-sm font-medium text-navy-900 duration-100 placeholder:text-gray-500 hover:bg-gray-100 focus:bg-gray-200 active:bg-gray-200 dark:border-white/10 dark:bg-navy-800 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/20 dark:active:bg-white/20"
                    type="submit"
                  >
                    <input
                      type="hidden"
                      name="pathName"
                      value={usePathname()}
                    />
                    <FiLogOut
                      className="h-[16px] w-[16px] text-inherit"
                      width="16px"
                      height="16px"
                      color="inherit"
                    />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </Scrollbars>
      </Card>
    </div>
  );
}

// PROPS

export default Sidebar;
