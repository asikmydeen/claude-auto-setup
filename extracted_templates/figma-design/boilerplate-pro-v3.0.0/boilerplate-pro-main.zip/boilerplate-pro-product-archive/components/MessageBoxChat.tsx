import Card from '@/components/card/Card';
import ReactMarkdown from 'react-markdown';

export default function MessageBox(props: { output: string }) {
  const { output } = props;
  return (
    <Card
      extra={`${
        output ? 'flex' : 'hidden'
      } !px-[22px] !py-[22px] !max-h-max dark:!bg-white/10 p-5 backdrop-blur-xl dark:border-[0px] dark:border-white/20 text-navy-900 dark:text-white text-sm md:text-base leading-[24px] md:leading-[26px] font-medium`}
    >
      <ReactMarkdown className="font-medium">
        {output ? output : ''}
      </ReactMarkdown>
    </Card>
  );
}
