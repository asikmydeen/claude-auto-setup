import ReactMarkdown from 'react-markdown';

export default function MessageBox(props: { output: string }) {
  const { output } = props;
  return (
    <div className="mb-7 flex min-h-[564px] w-full min-w-fit rounded-[10px] border-[1px] border-gray-200 px-5 py-4 font-medium text-navy-900 dark:border-white/20 dark:text-white">
      <ReactMarkdown className="font-medium dark:text-gray-400">
        {output ? output : 'Your generated response will appear here...'}
      </ReactMarkdown>
    </div>
  );
}
