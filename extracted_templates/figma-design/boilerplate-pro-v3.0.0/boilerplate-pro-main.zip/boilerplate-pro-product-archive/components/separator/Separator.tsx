'use client';

const HSeparator = (props: {
  extra?: string;
  variant?: string;
  [x: string]: any;
}) => {
  const { extra, variant, ...rest } = props;
  return (
    <div
      className={`h-[1px] w-full bg-gray-200 dark:bg-white/30 ${extra}`}
      {...rest}
    />
  );
};

const VSeparator = (props: {
  extra?: string;
  variant?: string;
  [x: string]: any;
}) => {
  const { extra, variant, ...rest } = props;
  return (
    <div
      className={`h-full w-[1px] bg-gray-200 dark:bg-white/30 ${extra}`}
      {...rest}
    />
  );
};

export { HSeparator, VSeparator };
