import Card from '@/components/card/Card';
import CardMenu from '@/components/card/CardMenu';
import Checkbox from '@/components/checkbox';
import {
  PaginationState,
  createColumnHelper,
  useReactTable,
  ColumnFiltersState,
  getCoreRowModel,
  getFilteredRowModel,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFacetedMinMaxValues,
  getPaginationRowModel,
  getSortedRowModel,
  flexRender
} from '@tanstack/react-table';
import React from 'react';
import { MdChevronRight, MdChevronLeft } from 'react-icons/md';

type RowObj = {
  checked?: string;
  email: string;
  provider: string;
  created: string;
  lastsigned: string;
  uuid: string;
  menu?: string;
};

function CheckTable(props: { tableData: any }) {
  const { tableData } = props;
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  let defaultData = tableData;
  const [globalFilter, setGlobalFilter] = React.useState('');
  const createPages = (count: number) => {
    let arrPageCount = [];

    for (let i = 1; i <= count; i++) {
      arrPageCount.push(i);
    }

    return arrPageCount;
  };
  const columns = [
    columnHelper.accessor('checked', {
      id: 'checked',
      header: () => (
        <div className="max-w-max">
          <Checkbox me="10px" />
        </div>
      ),
      cell: (info: any) => (
        <div className="flex max-w-max items-center">
          <Checkbox defaultChecked={info.getValue()[1]} />
        </div>
      )
    }),
    columnHelper.accessor('email', {
      id: 'email',
      header: () => (
        <p className="text-xs font-bold text-gray-500 dark:text-white">
          EMAIL ADDRESS
        </p>
      ),
      cell: (info) => (
        <p className="text-sm font-bold text-navy-900 dark:text-white">
          {info.getValue()}
        </p>
      )
    }),
    columnHelper.accessor('created', {
      id: 'created',
      header: () => (
        <p className="text-xs font-bold text-gray-500 dark:text-white">
          CREATED
        </p>
      ),
      cell: (info: any) => (
        <div className="flex w-full items-center gap-[14px]">
          <p className="text-sm font-bold text-navy-900 dark:text-white">
            {info.getValue()}
          </p>
        </div>
      )
    }),
    columnHelper.accessor('provider', {
      id: 'provider',
      header: () => (
        <p className="text-xs font-bold text-gray-500 dark:text-white">
          PROVIDER
        </p>
      ),
      cell: (info: any) => (
        <div className="flex w-full items-center gap-[14px]">
          <p className="text-sm font-bold text-navy-900 dark:text-white">
            {info.getValue()}
          </p>
        </div>
      )
    }),
    columnHelper.accessor('lastsigned', {
      id: 'lastsigned',
      header: () => (
        <p className="text-xs font-bold text-gray-500 dark:text-white">
          LAST SIGN IN
        </p>
      ),
      cell: (info) => (
        <p className="text-sm font-bold text-navy-900 dark:text-white">
          {info.getValue()}
        </p>
      )
    }),
    columnHelper.accessor('uuid', {
      id: 'uuid',
      header: () => (
        <p className="text-xs font-bold text-gray-500 dark:text-white">
          USER UID
        </p>
      ),
      cell: (info) => (
        <p className="text-sm font-bold text-navy-900 dark:text-white">
          {info.getValue()}
        </p>
      )
    }),
    columnHelper.accessor('menu', {
      id: 'menu',
      header: () => (
        <p className="fxst-bold text-sm text-gray-500 dark:text-white"></p>
      ),
      cell: (info) => <CardMenu vertical={true} />
    })
  ]; // eslint-disable-next-line
  const [data, setData] = React.useState(() => [...defaultData]);
  const [{ pageIndex, pageSize }, setPagination] = React.useState<
    PaginationState
  >({
    pageIndex: 0,
    pageSize: 11
  });

  const pagination = React.useMemo(
    () => ({
      pageIndex,
      pageSize
    }),
    [pageIndex, pageSize]
  );
  const table = useReactTable({
    data,
    columns,
    state: {
      columnFilters,
      globalFilter,
      pagination
    },
    onPaginationChange: setPagination,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues(),
    debugTable: true,
    debugHeaders: true,
    debugColumns: false
  });

  return (
    <Card extra={'w-full h-full sm:overflow-auto p-0'}>
      <div className="mt-6 overflow-x-scroll xl:overflow-x-hidden">
        <table className="w-full">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id} className="!border-gray-400 p-6">
                {headerGroup.headers.map((header) => {
                  return (
                    <th
                      key={header.id}
                      colSpan={header.colSpan}
                      onClick={header.column.getToggleSortingHandler()}
                      className="cursor-pointer border-b border-gray-200 pb-7 pl-6 pr-4 text-start dark:border-white/10"
                    >
                      <div className="items-center justify-between text-xs text-gray-200 dark:text-gray-400">
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        {{
                          asc: '',
                          desc: ''
                        }[header.column.getIsSorted() as string] ?? null}
                      </div>
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>
          <tbody>
            {table
              .getRowModel()
              .rows.slice(0, 7)
              .map((row) => {
                return (
                  <tr key={row.id} className="px-6">
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <td
                          key={cell.id}
                          className="w-max border-b-[1px] border-gray-200 py-6 pl-6 pr-4 dark:border-white/10"
                        >
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
          </tbody>
        </table>
        {/* pagination */}
        <div className="mt-2 flex h-20 w-full items-center justify-between px-6">
          {/* left side */}
          <div className="flex items-center gap-3">
            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
              Showing 6 rows per page
            </p>
          </div>
          {/* right side */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
              className={`flex items-center justify-center rounded-full bg-transparent p-2 text-lg text-gray-500 transition duration-200 dark:text-white`}
            >
              <MdChevronLeft />
            </button>

            {/* {createPages(table.getPageCount()).map((pageNumber, index) => {
              return (
                <button
                  className={`font-mediumflex p-0 items-center justify-center rounded-full p-2 text-sm transition duration-200 ${
                    pageNumber === pageIndex + 1
                      ? 'bg-brand-500 text-white hover:bg-brand-600 active:bg-brand-700 dark:bg-brand-400 dark:text-white dark:hover:bg-brand-300 dark:active:bg-brand-200'
                      : 'border-[1px] border-gray-400 bg-[transparent] dark:border-white dark:text-white'
                  }`}
                  onClick={() => table.setPageIndex(pageNumber - 1)}
                  key={index}
                >
                  {pageNumber}
                </button>
              );
            })} */}
            <button
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
              className={`font-mediumflex items-center justify-center rounded-full bg-transparent p-2 text-lg text-gray-500 transition duration-200 dark:text-white`}
            >
              <MdChevronRight />
            </button>
          </div>
        </div>
      </div>
    </Card>
  );
}

export default CheckTable;
const columnHelper = createColumnHelper<RowObj>();
