/*eslint-disable*/
'use client';

import MessageBox from '@/components/MessageBox';
import Card from '@/components/card/Card';
import DashboardLayout from '@/components/layout';
import { EssayBody, OpenAIModel } from '@/types/types';
import { Database } from '@/types_db';
import { User } from '@supabase/supabase-js';
import { useState } from 'react';
import { MdChevronRight, MdOutlineWorkspacePremium } from 'react-icons/md';
import Link from 'next/link';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}

interface Props {
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null;
  userDetails: { [x: string]: any } | null;
}

export default function EssayGenerator(props: Props) {
  // *** If you use .env.local variable for your API key, method which we recommend, use the apiKey variable commented below

  // Input States
  const [words, setWords] = useState<'300' | '200'>('200');
  const [essayType, setEssayType] = useState<
    '' | 'Argumentative' | 'Classic' | 'Persuasive' | 'Critique'
  >('Argumentative');
  const [topic, setTopic] = useState<string>('');
  // Response message
  const [outputCode, setOutputCode] = useState<string>('');
  // ChatGPT model
  const [model, setModel] = useState<OpenAIModel>('gpt-3.5-turbo');
  // Loading state
  const [loading, setLoading] = useState<boolean>(false);

  // -------------- Main API Handler --------------
  const handleTranslate = async () => {
    const maxCodeLength = model === 'gpt-3.5-turbo' ? 700 : 700;

    // Chat post conditions(maximum number of characters, valid message etc.)

    // if (!apiKey?.includes('sk-') && !apiKey?.includes('sk-')) {
    //   alert('Please enter an API key.');
    //   return;
    // }

    if (!topic) {
      alert('Please enter your subject.');
      return;
    }
    if (!words) {
      alert('Please choose number of words.');
      return;
    }
    if (!essayType) {
      alert('Please choose a type of essay.');
      return;
    }
    if (topic.length > maxCodeLength) {
      alert(
        `Please enter code less than ${maxCodeLength} characters. You are currently at ${topic.length} characters.`
      );
      return;
    }

    setLoading(true);
    setOutputCode('');

    const controller = new AbortController();

    const body: EssayBody = {
      topic,
      words,
      essayType,
      model
    };

    // -------------- Fetch --------------
    const response = await fetch('/api/essayAPI', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      signal: controller.signal,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      setLoading(false);
      if (response) {
        console.log(response);
        alert(
          'Something went wrong went fetching from the API. Make sure to use a valid API key.'
        );
      }
      return;
    }

    const data = response.body;

    if (!data) {
      setLoading(false);
      alert('Something went wrong');
      return;
    }

    const reader = data.getReader();
    const decoder = new TextDecoder();
    let done = false;
    let code = '';

    while (!done) {
      const { value, done: doneReading } = await reader.read();
      done = doneReading;
      const chunkValue = decoder.decode(value);

      code += chunkValue;

      setOutputCode((prevCode) => prevCode + chunkValue);
    }

    setLoading(false);
    copyToClipboard(code);
  };

  // -------------- Copy Response --------------
  const copyToClipboard = (text: string) => {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  };

  // *** Initializing apiKey with .env.local value
  // useEffect(() => {
  // ENV file verison
  //   const apiKeyENV = process.env.NEXT_PUBLIC_OPENAI_API_KEY;
  //   if (apiKey === undefined || null) {
  //     setApiKey(apiKeyENV);
  //   }
  // }, []);

  // -------------- Input Value Handler --------------
  const handleChange = (Event: any) => {
    setTopic(Event.target.value);
  };
  const handleChangeParagraphs = (Event: any) => {
    setWords(Event.target.value);
  };
  const handleChangeEssayType = (Event: any) => {
    setEssayType(Event.target.value);
  };
  return (
    <DashboardLayout
      userDetails={props.userDetails}
      user={props.user}
      products={props.products}
      subscription={props.subscription}
      title="AI Generator"
      description="AI Generator"
    >
      <div className="relative flex w-full flex-col">
        <div className="mx-auto flex w-full max-w-full flex-col justify-center md:w-full md:flex-row xl:w-full">
          <Card extra="min-w-full md:min-w-[40%] xl:min-w-[476px] h-min p-5 mr-0 md:mr-5 mb-5 md:mb-0">
            <p className="mb-2.5 text-[30px]  font-extrabold text-navy-900 dark:text-white">
              Essay Topic
            </p>
            <p className="mb-6 font-medium text-gray-500 dark:text-gray-400">
              What your essay will be about?
            </p>
            <textarea
              className="mb-7 min-h-[224px] rounded-[10px] border-[1px] border-gray-200 bg-white px-5 py-[15px] font-medium text-navy-900 !outline-none placeholder:text-gray-500 focus:placeholder:border-gray-200 dark:border-white/20 dark:bg-transparent dark:text-white dark:text-white/60 dark:placeholder:text-gray-400 focus:placeholder:dark:border-white/20"
              placeholder="Type here your topic..."
              onChange={handleChange}
            />
            <label
              className="mb-2 ml-1.5 mr-2.5 flex cursor-pointer font-bold text-navy-900 dark:text-white"
              htmlFor="parag"
            >
              Number of words
            </label>
            <select
              className="mb-7 h-[60px] rounded-[10px] border-[1px] border-gray-200 bg-white px-5 font-medium text-navy-900 !outline-none placeholder:text-gray-500 focus:placeholder:border-gray-200 dark:border-white/20 dark:bg-transparent dark:text-white dark:text-white/60 dark:placeholder:text-gray-400 focus:placeholder:dark:border-white/20"
              id="type"
              onChange={handleChangeParagraphs}
            >
              <option value={'200'}>200</option>
              <option value={'300'}>300</option>
            </select>
            <label
              className="mb-2 ml-1.5 mr-2.5 flex cursor-pointer font-bold text-navy-900 dark:text-white"
              htmlFor={'type'}
            >
              Select your Essay type
            </label>
            <select
              className="mb-7 h-[60px] rounded-[10px] border-[1px] border-gray-200 bg-white px-5 font-medium text-navy-900 !outline-none placeholder:text-gray-500 focus:placeholder:border-gray-200 dark:border-white/20 dark:bg-transparent dark:text-white dark:text-white/60 focus:placeholder:dark:border-white/20"
              id="type"
              onChange={handleChangeEssayType}
            >
              <option value="Argumentative">Argumentative</option>
              <option value="Classic">Classic</option>
              <option value="Persuasive">Persuasive</option>
              <option value="Critique">Critique</option>
            </select>
            {props.subscription ? (
              <div className="flex flex-col">
                <p className="mb-3 ml-2.5 text-[30px] font-bold text-navy-900 dark:text-white">
                  Looking for all features?
                </p>
                <Link href="/dashboard/premium-essays">
                  <div className="mb-7 flex h-[60px] items-center rounded-[14px] border-[1px] border-gray-200 px-4 py-3.5 font-medium text-navy-900 !outline-none placeholder:text-gray-500 focus:placeholder:border-gray-200 dark:border-white/20 dark:text-white dark:text-white/60 focus:placeholder:dark:border-white/20">
                    <div className="mr-2.5 flex h-max rounded-[99px] border-[1px] border-gray-200 p-2.5">
                      <MdOutlineWorkspacePremium className="h-5 w-5 text-brand-500" />
                    </div>
                    <p className="mr-2.5 font-bold text-navy-900 dark:text-white">
                      Try our Premium Essay Generator
                    </p>
                    <MdChevronRight className="-mb-0.5 ml-auto mr-1 h-5 w-5 text-navy-900 dark:text-white" />
                  </div>
                </Link>
              </div>
            ) : (
              ''
            )}
            <button
              className="mb-3.5 flex w-full items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] "
              onClick={handleTranslate}
            >
              {loading ? (
                <svg
                  aria-hidden="true"
                  role="status"
                  className="mr-2 inline h-4 w-4 animate-spin text-gray-200 duration-75 dark:text-gray-500"
                  viewBox="0 0 100 101"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                    fill="currentColor"
                  ></path>
                  <path
                    d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                    fill="white"
                  ></path>
                </svg>
              ) : (
                'Generate your Essay'
              )}
            </button>
          </Card>
          <Card extra="w-stretch max-w-full w-full h-full p-5 mr-0 md:mr-5 mb-5 md:mb-0 ">
            <p className="mb-2.5 text-[30px]  font-extrabold text-navy-900 dark:text-white">
              AI Output
            </p>
            <p className="mb-[30px] font-medium text-gray-500 dark:text-gray-400">
              Enjoy your outstanding essay!
            </p>
            <MessageBox output={outputCode} />
            <button
              className="linear h-[54px] w-[300px] max-w-[160px] rounded-full border-[1px] border-gray-200 font-medium duration-[0.2s] hover:bg-gray-100 dark:border-white/20 md:w-[420px] "
              onClick={() => {
                if (outputCode) navigator.clipboard.writeText(outputCode);
              }}
            >
              Copy text
            </button>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
