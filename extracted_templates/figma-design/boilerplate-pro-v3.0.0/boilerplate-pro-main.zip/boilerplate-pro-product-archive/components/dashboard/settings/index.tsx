/*eslint-disable*/
'use client';

// import ManageSubscriptionButton from './ManageSubscriptionButton';
import Card from '@/components/card/Card';
import DashboardLayout from '@/components/layout';
import { Database } from '@/types_db';
import { User } from '@supabase/supabase-js';
import { updateName, updateEmail } from '@/utils/auth-helpers/server';
import { useState } from 'react';
import { handleRequest } from '@/utils/auth-helpers/client';
import { useRouter } from 'next/navigation';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}

interface Props {
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null;
  userDetails: { [x: string]: any } | null;
}

export default function Settings(props: Props) {
  // Input States
  const [nameError, setNameError] = useState<{
    status: boolean;
    message: string;
  }>();

  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitEmail = async (e: React.FormEvent<HTMLFormElement>) => {
    setIsSubmitting(true);
    // Check if the new email is the same as the old email
    if (e.currentTarget.newEmail.value === props.user.email) {
      e.preventDefault();
      setIsSubmitting(false);
      return;
    }
    handleRequest(e, updateEmail, router);
    setIsSubmitting(false);
  };

  const handleSubmitName = async (e: React.FormEvent<HTMLFormElement>) => {
    setIsSubmitting(true);
    // Check if the new name is the same as the old name
    if (e.currentTarget.fullName.value === props.user.user_metadata.full_name) {
      e.preventDefault();
      setIsSubmitting(false);
      return;
    }
    handleRequest(e, updateName, router);
    setIsSubmitting(false);
  };

  return (
    <DashboardLayout
      userDetails={props.userDetails}
      user={props?.user}
      products={props.products}
      subscription={props.subscription}
      title="Account Settings"
      description="Profile settings."
    >
      <div className="relative mx-auto flex w-max max-w-full flex-col lg:pt-[160px]">
        <div className="maw-w-full mx-auto w-full flex-col justify-center md:w-full md:flex-row xl:w-full">
          <Card
            extra={
              'max-w-full py-4 md:px-7 lg:px-7 lg:py-7 md:py-10 lg:py-10 w-[820px] h-min mr-0 mb-5 md:mb-0'
            }
          >
            <p className="pl-2.5 text-xl font-extrabold text-navy-900 dark:text-white md:pl-8 md:text-[30px]">
              Account Settings
            </p>
            <p className="mb-8 mt-1 pl-2.5 text-sm font-medium text-gray-500 dark:text-gray-400 md:mt-4 md:pl-8 md:text-base">
              Here you can change your account information
            </p>
            <label
              className="mb-3 ml-2.5 flex cursor-pointer px-2.5 font-bold leading-none text-navy-900 dark:text-white md:px-8"
              htmlFor={'name'}
            >
              Your Name
              <p className="ml-1 mt-[1px] text-sm font-medium leading-none text-gray-500 dark:text-gray-400">
                (30 characters maximum)
              </p>
            </label>
            <div className="mb-[30px] flex flex-col px-2.5 md:mb-0 md:flex-row md:px-8">
              <form
                className="w-full"
                id="nameForm"
                onSubmit={(e) => handleSubmitName(e)}
              >
                <input
                  placeholder="Please enter your full name"
                  type="text"
                  name="fullName"
                  defaultValue={props.user?.user_metadata.full_name ?? ''}
                  className={`mb-8 mr-4 flex h-[54px] w-full items-center justify-center rounded-full border border-gray-200 bg-white/0 px-4 py-5 text-navy-900 outline-none dark:!border-white/10 dark:text-white`}
                />
              </form>
              <button
                className="mb-2 ms-2 flex h-[54px] min-w-[150px] items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:mb-8"
                form="nameForm"
                type="submit"
              >
                Update name
              </button>
              <div className="mt-[30px] h-px w-full max-w-[90%] self-center bg-gray-200 dark:bg-white/10 md:mt-0 md:hidden" />
            </div>
            <p
              className={`mb-5 px-2.5 text-red-500 md:px-9 ${
                nameError?.status ? 'block' : 'hidden'
              }`}
            >
              {nameError?.message}
            </p>
            <label
              className="mb-3 ml-2.5 flex cursor-pointer px-2.5 font-bold leading-none text-navy-900 dark:text-white md:px-8"
              htmlFor={'email'}
            >
              Your Email
              <p className="ml-1 mt-[1px] text-sm font-medium leading-none text-gray-500 dark:text-gray-400">
                (We will email you to verify the change)
              </p>
            </label>
            <div className="flex flex-col px-2.5 md:mb-0 md:flex-row md:px-8">
              <form
                className="w-full"
                id="emailForm"
                onSubmit={(e) => handleSubmitEmail(e)}
              >
                <input
                  placeholder="Please enter your email"
                  defaultValue={props.user.email ?? ''}
                  type="text"
                  name="newEmail"
                  className={`mb-3.5 mr-4 flex h-[54px] w-full items-center justify-center rounded-full border border-gray-200 bg-white/0 px-4 py-5 text-navy-900 outline-none dark:!border-white/10 dark:text-white`}
                />
              </form>
              <button
                className="mb-3.5 ms-2 flex h-[54px] min-w-[150px] items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important]"
                type="submit"
                form="emailForm"
              >
                Update email
              </button>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
