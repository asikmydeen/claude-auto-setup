'use client';

/*eslint-disable*/
import MessageBoxChat from '@/components/MessageBoxChat';
import DashboardLayout from '@/components/layout';
import Bg from '@/public/img/ai-chat/bg-image.png';
import { ChatBody, OpenAIModel } from '@/types/types';
import { Database } from '@/types_db';
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel
} from '@chakra-ui/accordion';
import { User } from '@supabase/supabase-js';
import Image from 'next/image';
import { useState } from 'react';
import { MdAutoAwesome, MdBolt, MdEdit, MdPerson } from 'react-icons/md';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}

interface Props {
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null;
  userDetails: { [x: string]: any } | null;
}
export default function Chat(props: Props) {
  // *** If you use .env.local variable for your API key, method which we recommend, use the apiKey variable commented below
  // Input States
  const [inputOnSubmit, setInputOnSubmit] = useState<string>('');
  const [inputMessage, setInputMessage] = useState<string>('');
  // Response message
  const [outputCode, setOutputCode] = useState<string>('');
  // ChatGPT model
  const [model, setModel] = useState<OpenAIModel>('gpt-3.5-turbo');
  // Loading state
  const [loading, setLoading] = useState<boolean>(false);

  // API Key
  const handleTranslate = async () => {
    setInputOnSubmit(inputMessage);

    // Chat post conditions(maximum number of characters, valid message etc.)
    const maxCodeLength = model === 'gpt-3.5-turbo' ? 700 : 700;

    if (!inputMessage) {
      alert('Please enter your subject.');
      return;
    }

    if (inputMessage.length > maxCodeLength) {
      alert(
        `Please enter code less than ${maxCodeLength} characters. You are currently at ${inputMessage.length} characters.`
      );
      return;
    }
    setOutputCode(' ');
    setLoading(true);
    const controller = new AbortController();
    const body: ChatBody = {
      inputMessage,
      model
    };

    // -------------- Fetch --------------
    const response = await fetch('/api/chatAPI', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      signal: controller.signal,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      setLoading(false);
      if (response) {
        alert(
          'Something went wrong went fetching from the API. Make sure to use a valid API key.'
        );
      }
      return;
    }

    const data = response.body;

    if (!data) {
      setLoading(false);
      alert('Something went wrong');
      return;
    }

    const reader = data.getReader();
    const decoder = new TextDecoder();
    let done = false;

    while (!done) {
      setLoading(true);
      const { value, done: doneReading } = await reader.read();
      done = doneReading;
      const chunkValue = decoder.decode(value);
      setOutputCode((prevCode) => prevCode + chunkValue);
    }

    setLoading(false);
  };
  // -------------- Copy Response --------------
  // const copyToClipboard = (text: string) => {
  //   const el = document.createElement('textarea');
  //   el.value = text;
  //   document.body.appendChild(el);
  //   el.select();
  //   document.execCommand('copy');
  //   document.body.removeChild(el);
  // };

  const handleChange = (Event: any) => {
    setInputMessage(Event.target.value);
  };

  return (
    <DashboardLayout
      userDetails={props.userDetails}
      user={props?.user}
      products={props.products}
      subscription={props.subscription}
      title="AI Generator"
      description="AI Generator"
    >
      <div className="relative flex w-full flex-col pt-[20px] md:pt-0">
        <Image
          width="340"
          height="181"
          src={Bg.src}
          className="absolute left-[20%] top-[50%] z-[0] w-[200px] translate-y-[-50%] md:left-[35%] lg:left-[38%] xl:left-[38%] xl:w-[350px] "
          alt=" "
        />
        <div className="mx-auto flex min-h-[75vh] w-full max-w-[1000px] flex-col xl:min-h-[85vh]">
          {/* Model Change */}
          <div
            className={`flex w-full flex-col ${
              outputCode ? 'mb-5' : 'mb-auto'
            }`}
          >
            <div className="z-[2] mx-auto mb-5 flex w-max rounded-[60px]">
              <div
                className={`flex cursor-pointer items-center justify-center py-4 duration-[0.3s] ${
                  model === 'gpt-3.5-turbo'
                    ? 'bg-white dark:bg-white/10'
                    : 'transparent'
                } h-[70xp] w-[174px]
              ${
                model === 'gpt-3.5-turbo'
                  ? 'shadow-[14px_27px_45px_rgba(112,_144,_176,_0.2)] dark:shadow-[unset]'
                  : ''
              } rounded-[14px] text-lg font-bold text-navy-900 dark:text-white`}
                onClick={() => setModel('gpt-3.5-turbo')}
              >
                <div className="mr-2.5 flex h-[39px] w-[39px] items-center justify-center rounded-full bg-white/20 bg-[linear-gradient(180deg,_#FBFBFF_0%,_#CACAFF_100%)] dark:bg-[linear-gradient(180deg,_rgba(255,_255,_255,_0.07)_0%,_rgba(255,_255,_255,_0.31)_100%)]">
                  <MdAutoAwesome className="h-[20px] w-[20px] text-brand-500 dark:text-white" />
                </div>
                GPT-3.5
              </div>
              <div
                className={`flex cursor-pointer items-center justify-center py-4 duration-[0.3s] ${
                  model === 'gpt-4-1106-preview'
                    ? 'bg-white dark:bg-white/10'
                    : 'transparent'
                } h-[70xp] w-[174px]
              ${
                model === 'gpt-4-1106-preview'
                  ? 'shadow-[14px_27px_45px_rgba(112,_144,_176,_0.2)] dark:shadow-[unset]'
                  : ''
              } rounded-[14px] text-lg font-bold text-navy-900 dark:text-white`}
                onClick={() => setModel('gpt-4-1106-preview')}
              >
                <div className="mr-2.5 flex h-[39px] w-[39px] items-center justify-center rounded-full bg-white/20 bg-[linear-gradient(180deg,_#FBFBFF_0%,_#CACAFF_100%)] dark:bg-[linear-gradient(180deg,_rgba(255,_255,_255,_0.07)_0%,_rgba(255,_255,_255,_0.31)_100%)]">
                  <MdBolt className="h-[20px] w-[20px] text-brand-500 dark:text-white" />
                </div>
                GPT-4
              </div>
            </div>

            <Accordion
              className="z-10 mx-auto my-0 w-full text-gray-500 dark:text-white"
              allowToggle
            >
              <AccordionItem border="none">
                <AccordionButton
                  borderBottom="0px solid"
                  maxW="max-content"
                  mx="auto"
                  _hover={{ border: '0px solid', bg: 'none' }}
                  _focus={{ border: '0px solid', bg: 'none' }}
                >
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                      No plugins added
                    </p>
                  </div>
                  <AccordionIcon className="text-gray-500 dark:text-gray-400" />
                </AccordionButton>
                <AccordionPanel mx="auto" w="max-content" p="0px 0px 10px 0px">
                  <p className="text-center text-sm font-medium text-gray-500 dark:text-gray-400">
                    This is a cool text example.
                  </p>
                </AccordionPanel>
              </AccordionItem>
            </Accordion>
          </div>
          {/* Main Box */}
          <div
            className={`mx-auto flex  w-full flex-col ${
              outputCode ? 'flex' : 'hidden'
            } mb-auto`}
          >
            <div className="mb-2.5 flex w-full items-center text-center">
              <div className="mr-5  flex h-[40px] min-h-[40px] min-w-[40px] items-center justify-center rounded-full border-[1px] border-gray-200 bg-transparent dark:border-white/20">
                <MdPerson className="text h-5 w-5 text-brand-500 dark:text-white" />
              </div>
              <div className="z-[2] flex w-full rounded-[14px] border-[1px] border-gray-200 bg-white/10 p-5 backdrop-blur-xl dark:border-[0px] dark:border-white/20">
                <p className="text-sm font-[600] leading-[24px] text-navy-900 dark:text-white md:text-base md:leading-[26px]">
                  {inputOnSubmit}
                </p>
                <MdEdit className="ml-auto h-[20px] w-[20px] cursor-pointer text-gray-500 dark:text-gray-400" />
              </div>
            </div>
            <div className="flex w-full">
              <div className="mr-5 flex h-10 min-h-[40px] min-w-[40px] items-center justify-center rounded-full bg-[linear-gradient(15.46deg,_#4A25E1_26.3%,_#7B5AFF_86.4%)] dark:bg-[linear-gradient(180deg,_rgba(255,_255,_255,_0.07)_0%,_rgba(255,_255,_255,_0.31)_100%)]">
                <MdAutoAwesome className="h-5 w-5 text-white" />
              </div>
              <MessageBoxChat output={outputCode} />
            </div>
          </div>
          {/* Chat Input */}
          <div className="mt-5 flex justify-end">
            <input
              className="mr-2.5 h-full min-h-[54px] w-full rounded-full border-[1px] border-gray-200 bg-white px-5 py-5 text-sm font-medium text-navy-900 placeholder:text-gray-500 focus:outline-0 dark:border-white/20 dark:bg-transparent dark:text-white/60 dark:placeholder:text-gray-500"
              placeholder="Type your message here..."
              onChange={handleChange}
            />
            <button
              className="linear mb-3.5 flex items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-[30px] py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:px-[70px] "
              onClick={handleTranslate}
            >
              Submit
            </button>
          </div>

          <div className="mt-5 flex flex-col items-center justify-center md:flex-row">
            <p className="text-center text-xs text-gray-500 dark:text-white">
              Free Research Preview. ChatGPT may produce inaccurate information
              about people, places, or facts. Consider checking important
              information.
            </p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
