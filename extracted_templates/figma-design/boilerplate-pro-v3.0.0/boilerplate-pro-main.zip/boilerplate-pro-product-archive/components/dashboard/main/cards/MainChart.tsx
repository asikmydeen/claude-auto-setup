'use client';

import Card from '@/components/card';
import LineChart from '@/components/charts/LineChart';
import { lineChartDataMain } from '@/variables/charts';
import { lineChartOptionsMain } from '@/variables/charts';
import { MdInsights } from 'react-icons/md';

function OverallRevenue() {
  const newOptions = {
    ...lineChartOptionsMain
    // colors: ['var(--color-500)' ],
  };

  return (
    <Card extra={'h-[381px] p-6'}>
      <div className="flex items-center gap-3">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-lightPrimary text-4xl text-brand-500 dark:!bg-navy-700 dark:text-white">
          <MdInsights className="y-6 w-6" />
        </div>
        <div>
          <h5 className="text-sm font-medium leading-5 text-gray-500 dark:text-gray-400">
            Credits usage in the last year
          </h5>
          <p className="mt-1 text-2xl font-bold leading-6 text-navy-900 dark:text-white">
            149,758
          </p>
        </div>
      </div>

      {/* Charts */}
      <div className="flex h-full w-full flex-row sm:flex-wrap lg:flex-nowrap 2xl:overflow-hidden">
        <div className="h-full w-full">
          <LineChart chartData={lineChartDataMain} chartOptions={newOptions} />
        </div>
      </div>
    </Card>
  );
}

export default OverallRevenue;
