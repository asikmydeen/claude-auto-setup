const Statistics = (props: {
  icon?: JSX.Element;
  title: string;
  value: number | string;
  endContent?: JSX.Element;
}) => {
  const { icon, title, value, endContent } = props;
  return (
    <div className="flex w-full justify-between rounded-[14px] bg-white bg-clip-border p-6 shadow-3xl shadow-shadow-500 dark:!bg-navy-800 dark:shadow-none">
      <div className="flex items-center gap-3">
        {icon}
        <div>
          <h5 className="text-sm font-medium leading-5 text-gray-500 dark:text-gray-400">
            {title}
          </h5>
          <p className="mt-1 text-2xl font-bold leading-6 text-navy-900 dark:text-white">
            {value}
          </p>
        </div>
      </div>

      {endContent}
    </div>
  );
};

export default Statistics;
