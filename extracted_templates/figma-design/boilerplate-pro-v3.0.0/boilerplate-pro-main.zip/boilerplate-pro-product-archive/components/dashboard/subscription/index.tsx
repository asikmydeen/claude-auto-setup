/*eslint-disable*/
'use client';

import Card from '@/components/card/Card';
import DashboardLayout from '@/components/layout';
import { Database } from '@/types_db';
import { postData } from '@/utils/helpers';
import { createStripePortal } from '@/utils/stripe/server';
import { User } from '@supabase/supabase-js';
import Link from 'next/link';
import { redirect, usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import { MdChevronRight } from 'react-icons/md';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}

interface Props {
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null | any;
  userDetails: { [x: string]: any } | null | any;
}

export default function Settings(props: Props) {
  const router = useRouter();
  const currentPath = usePathname();
  const { subscription } = props;
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleStripePortalRequest = async () => {
    setIsSubmitting(true);
    const redirectUrl = await createStripePortal(currentPath);
    setIsSubmitting(false);
    return router.push(redirectUrl);
  };

  if (!props.user) {
    return redirect('/dashboard/signin');
  }

  return (
    <DashboardLayout
      userDetails={props.userDetails}
      user={props.user}
      products={props.products}
      subscription={subscription}
      title="Subscription Page"
      description="Manage your subscriptions"
    >
      <div className="relative mt-[70px] w-full flex-col md:mt-0 xl:mt-0">
        <div className="mx-auto w-full max-w-max flex-col justify-center md:flex-row lg:pt-[100px]">
          <Card extra="w-[830px_!important] max-w-full p-3 items-center">
            <Card extra="bg-[linear-gradient(15deg,_#4A25E1_26.3%,_#7B5AFF_86.4%)] w-full max-w-full px-5 mb-2 md:px-10 lg:px-[50px] py-7 md:py-10 lg:py-[50px]">
              <p className="mb-2.5 w-max rounded-lg bg-white/10 px-1.5 py-1.5 text-sm font-bold text-white">
                CURRENT PLAN
              </p>
              {subscription ? (
                props.products?.map((product: any) => {
                  const price = product?.prices?.find(
                    (price: any) => price.id === subscription?.price_id
                  );
                  if (price?.id === subscription.price_id)
                    return (
                      // IN CASE USER HAS PLAN
                      <div className="flex flex-col justify-between md:flex-row">
                        <div className="flex flex-col">
                          <p className="text-[30px]  font-extrabold text-white md:text-[44px]">
                            {product?.name
                              ? product.name?.toString()
                              : 'No plan active'}
                          </p>
                          <p className="mb-5 text-sm font-medium text-white md:mb-0 md:text-xl">
                            {product?.name
                              ? `You are currently on ${product.name?.toString()}`
                              : "You don't have an active subscription."}
                          </p>
                        </div>
                        <div className="flex flex-col">
                          <p className="mb-2.5 text-center text-lg font-extrabold text-white md:text-2xl">
                            $
                            {price?.unit_amount !== null
                              ? price?.unit_amount / 100
                              : '0'}
                            {price?.interval === 'year'
                              ? '/year'
                              : price?.interval === 'month'
                              ? '/month'
                              : 'error'}
                          </p>
                          <button
                            className="flex h-[54px] w-full items-center justify-center rounded-full border-[1px] border-white px-4 py-5 text-sm font-semibold text-white duration-[0.2s] hover:bg-white/20 focus:bg-white/30 active:bg-white/30 md:w-[266px]"
                            onClick={handleStripePortalRequest}
                          >
                            {props?.subscription
                              ? 'Manage your subscription'
                              : 'See pricing plans'}
                            <MdChevronRight
                              className={`${
                                props?.subscription ? 'hidden' : ''
                              } mt-0.5 h-[16px] w-[16px]`}
                            />
                          </button>
                        </div>
                      </div>
                    );
                })
              ) : (
                // IN CASE OF NO PLAN
                <div className="flex flex-col justify-between md:flex-row">
                  <div className="flex flex-col">
                    <p className="text-[30px]  font-extrabold text-white md:text-[44px]">
                      No plan active
                    </p>
                    <p className="mb-5 text-sm font-medium text-white md:mb-0 md:text-xl">
                      You don't have an active subscription.
                    </p>
                  </div>
                  <div className="flex flex-col">
                    <p className="mb-2.5 text-left text-lg  font-extrabold text-white md:text-center md:text-2xl lg:text-right">
                      $0/month
                    </p>
                    <Link href="/pricing">
                      <button className="flex h-[54px] w-full items-center justify-center rounded-full border-[1px] border-white px-4 py-5 text-sm font-semibold text-white hover:bg-white/20 focus:bg-white/30 active:bg-white/30 md:w-[266px]">
                        See pricing plans
                        <MdChevronRight
                          className={`${
                            props?.subscription ? 'hidden' : ''
                          } mt-0.5 h-[16px] w-[16px]`}
                        />
                      </button>
                    </Link>
                  </div>
                </div>
              )}
            </Card>
            <div className="flex flex-col items-center justify-center md:flex-row">
              <p className="text-ceneter mr-[2px] w-[70%] self-center py-4 text-sm font-medium text-gray-600 md:w-[unset] dark:text-gray-400">
                Got a question regarding your subscription? Chat with us via{' '}
              </p>
              <a href="mailto:hello@horizon-ui.com">
                <p className="text-cneter mr-[2px] w-[100%] self-center text-sm font-medium text-gray-600 underline md:w-[unset] dark:text-white">
                  hello@horizon-ui.com.
                </p>
              </a>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
