'use client';

// @ts-nocheck
// Custom components
import { FooterWebsite } from '../footer/FooterWebsite';
import Card from '@/components/card/Card';
import Faq from '@/components/landing/faq';
import InnerContent from '@/components/layout/innerContent';
import NavbarFixed from '@/components/navbar/NavbarFixed';
import { Database } from '@/types_db';
import { getStripe } from '@/utils/stripe/client';
import { User } from '@supabase/supabase-js';
import { usePathname, useRouter } from 'next/navigation';
import React, { useState } from 'react';
import {
  FaCcVisa,
  FaCcMastercard,
  FaCcPaypal,
  FaCcAmex,
  FaCcApplePay
} from 'react-icons/fa';
import {
  MdChevronRight,
  MdCheckCircle,
  MdAttachMoney,
  MdLock,
  MdOutlineDoDisturbOn
} from 'react-icons/md';
import { checkoutWithStripe } from '@/utils/stripe/server';
import { getErrorRedirect } from '@/utils/helpers';
import Link from 'next/link';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}

interface Props {
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null;
}

export default function Pricing({ user, products, subscription }: Props) {
  const router = useRouter();
  const [priceIdLoading, setPriceIdLoading] = useState<string>();
  const currentPath = usePathname();

  const handleCheckout = async (price: Price) => {
    setPriceIdLoading(price.id);

    if (!user) {
      setPriceIdLoading(undefined);
      return router.push('/dashboard/signin/signup');
    }

    const { errorRedirect, sessionId } = await checkoutWithStripe(
      price,
      currentPath
    );

    if (errorRedirect) {
      setPriceIdLoading(undefined);
      return router.push(errorRedirect);
    }

    if (!sessionId) {
      setPriceIdLoading(undefined);
      return router.push(
        getErrorRedirect(
          currentPath,
          'An unknown error occurred.',
          'Please try again later or contact a system administrator.'
        )
      );
    }

    const stripe = await getStripe();
    stripe?.redirectToCheckout({ sessionId });

    setPriceIdLoading(undefined);
  };
  const [version, setVersion] = useState('monthly');

  return (
    <div
      className="relative w-full flex-col overflow-hidden bg-cover pt-[120px] md:pt-[220px]"
      id="pricing"
    >
      <NavbarFixed />
      <InnerContent extra="z-[1] max-w-full md:max-w-full xl:max-w-[1170px] pb-[60px] md:pb-[100px]">
        {/* Title */}
        <div className="mb-20 w-full flex-col px-5 md:px-0">
          <div className="flex flex-col items-center justify-center px-5 text-start md:px-10 xl:px-0">
            <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base">
              PRICING PLANS
            </h6>
            <h1 className="w-full text-center text-[28px] font-extrabold leading-[38px] text-navy-900 md:w-[90%] md:text-[40px] md:leading-[50px] lg:w-[60%] xl:w-[70%] xl:text-[48px] xl:leading-[60px] 2xl:w-[60%]">
              Choose the right pricing plan for your and your business
            </h1>
          </div>
        </div>
        <div className="mb-5 flex w-full flex-col gap-5 px-5 md:px-0 lg:flex-row">
          <Card extra="bg-white max-w-[377px] mx-auto items-center p-4 md:p-[26px] !pt-[26px] !md:pt-9 flex-col dark:!bg-white dark:!shadow-shadow-500 dark:!shadow-3xl">
            <div className="mx-auto mb-5 flex">
              <p className="text-center text-[22px] font-semibold text-boilerplateNavy">
                Free Plan
              </p>
            </div>
            <div className="z-[1] mb-10 flex w-full flex-col rounded-[16px] bg-[#F3F5FA] px-[18px] pb-10 pt-10 md:px-[34px]">
              <div className="mb-[30px] flex flex-row justify-center">
                <p className="text-[48px]  font-extrabold leading-none text-boilerplateNavy md:text-[54px]">
                  Free
                </p>
              </div>
              <Link href="/dashboard/signin">
                <button className="mx-auto flex h-[54px] w-full items-center justify-center rounded-full bg-boilerplateNavy px-4 py-5 text-sm font-medium text-white duration-[0.2s] hover:shadow-[0px_11px_24px_-13px_rgba(10,_8,_38,_0.50)] active:shadow-[0px_21px_34px_-13px_rgba(10,_8,_38,_0.50)]">
                  Get started now
                  <MdChevronRight className="mt-0.5 h-4 w-4" />
                </button>
              </Link>
            </div>

            {/* Features */}
            <div className="flex w-full flex-col">
              <div className="mb-[30px] flex items-center">
                <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                  Standard Essays
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                  Up to 4 Essay types
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                  Up to 200 words per Essay
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdOutlineDoDisturbOn className="mr-2.5 h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-400 xl:text-base">
                  Essay Tones (Academic, etc.)
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdOutlineDoDisturbOn className="mr-2.5 h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-400 xl:text-base">
                  Academic Citation formats (APA, etc)
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdOutlineDoDisturbOn className="mr-2.5 h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-400 xl:text-base">
                  Academic Levels (Master, etc.)
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdOutlineDoDisturbOn className="mr-2.5 h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-400 xl:text-base">
                  Premium features
                </span>
              </div>
              <div className="mb-[30px] flex items-center">
                <MdOutlineDoDisturbOn className="mr-2.5 h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-400 xl:text-base">
                  Priority Support
                </span>
              </div>
            </div>
          </Card>
          {products.map((product) => {
            const price = product?.prices?.find(
              (price) => price.id === 'price_************************'
            );
            if (product.id === 'prod_**************') {
              if (!price) return null;
              return (
                <Card
                  extra="!bg-boilerplateNavy max-w-[377px] mx-auto items-center p-4 md:p-[26px] !pt-[26px] !md:pt-9 flex-col"
                  key={product.id}
                >
                  <div className="mx-auto mb-5 flex">
                    <p className="text-center text-[22px] font-semibold text-white">
                      {product.name?.toString()}
                    </p>
                  </div>
                  <div className="z-[1] mb-10 flex w-full flex-col rounded-[16px] bg-[linear-gradient(180deg,_rgba(255,_255,_255,_0.11)_0%,_rgba(255,_255,_255,_0.06)_50.63%,_rgba(255,_255,_255,_0.03)_100%)] px-[18px] pb-10 pt-10 shadow-[0px_8px_25px_-4px_rgba(255,_255,_255,_0.30)_inset] md:px-[34px]">
                    <div className="mb-[30px] flex flex-row justify-center">
                      <p className="text-[48px]  font-extrabold leading-none text-white md:text-[54px]">
                        $
                        {price.unit_amount !== null
                          ? price.unit_amount / 100
                          : price.unit_amount}
                      </p>
                      <div className="flex flex-col">
                        <p className="mb-1 mt-auto text-sm font-bold leading-none text-white">
                          {version !== 'yearly' ? '/month' : '/month'}
                        </p>
                      </div>
                    </div>
                    <button
                      className="mx-auto flex h-[54px] w-full items-center justify-center rounded-full bg-white/30 px-4 py-5 text-sm font-medium text-white duration-[0.2s] hover:bg-white/40 active:bg-white/50 "
                      onClick={() => handleCheckout(price)}
                    >
                      {subscription ? 'Manage' : 'Get started now'}
                      <MdChevronRight className="mt-0.5 h-4 w-4" />
                    </button>
                  </div>

                  {/* Features */}
                  <div className="flex w-full flex-col">
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Unlimited Premium Essays / month
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Access to 12+ Essay types
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Up to 1500 words per Essay
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Academic Citation formats (APA, etc)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Essay Tones (Academic, etc.)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Academic Levels (Master, etc.)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Exceptional Essays in seconds
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Easy-to-use Essay Generator
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-white" />
                      <span className="text-sm font-medium text-white xl:text-base">
                        Priority Support
                      </span>
                    </div>
                  </div>
                </Card>
              );
            }
          })}
          {products.map((product) => {
            const price = product?.prices?.find(
              (price) => price.id === 'price_************************'
            );
            if (product.id === 'prod_**************') {
              if (!price) return null;
              return (
                <Card
                  key={product.id}
                  extra="bg-white max-w-[377px] mx-auto items-center p-4 md:p-[26px] !pt-[26px] !md:pt-9 flex-col dark:!bg-white dark:!shadow-shadow-500 dark:!shadow-3xl"
                >
                  <div className="mx-auto mb-5 flex">
                    <p className="text-center text-[22px] font-semibold text-boilerplateNavy">
                      Yearly Plan
                    </p>
                  </div>
                  <div className="z-[1] mb-10 flex w-full flex-col rounded-[16px] bg-[#F3F5FA] px-[18px] pb-10 pt-10 md:px-[34px]">
                    <div className="mb-[30px] flex flex-row justify-center">
                      <p className="mr-2 bg-[linear-gradient(89deg,_#3D1DFF_9.03%,_#6147FF_30.23%,_#D451FF_52.91%,_#EC458D_80.02%,_#FFCA8B_103.68%)] bg-clip-text text-[48px]  font-extrabold leading-none text-[transparent] md:text-[54px]">
                        $
                        {price.unit_amount !== null
                          ? price.unit_amount / 100
                          : price.unit_amount}
                      </p>
                      <div className="flex flex-col">
                        <p className="mt-auto text-sm font-bold leading-none text-boilerplateNavy">
                          /year
                        </p>
                        <p className="mb-1 mt-2 text-sm font-medium leading-none text-boilerplateNavy line-through">
                          reg.$108
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCheckout(price)}
                      className="mx-auto flex h-[54px] w-full items-center justify-center rounded-full bg-boilerplateNavy px-4 py-5 text-sm font-medium text-white duration-[0.2s] hover:shadow-[0px_11px_24px_-13px_rgba(10,_8,_38,_0.50)] active:shadow-[0px_21px_34px_-13px_rgba(10,_8,_38,_0.50)]"
                    >
                      Get started now
                      <MdChevronRight className="mt-0.5 h-4 w-4" />
                    </button>
                  </div>

                  {/* Features */}
                  <div className="flex w-full flex-col">
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Unlimited Premium Essays / year
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Access to 12+ Essay types
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Up to 2500 words per Essay
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Academic Citation formats (APA, etc)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Essay Tones (Academic, etc.)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Academic Levels (Master, etc.)
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Exceptional Essays in seconds
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Easy-to-use Essay Generator
                      </span>
                    </div>
                    <div className="mb-[30px] flex items-center">
                      <MdCheckCircle className="mr-2.5 h-5 w-5 text-brand-500" />
                      <span className="text-sm font-medium text-boilerplateNavy xl:text-base">
                        Priority Support
                      </span>
                    </div>
                  </div>
                </Card>
              );
            }
          })}
        </div>
        <div className="mt-[30px] flex flex-col items-center px-5 md:px-0">
          <div className="mb-5 flex items-center">
            <MdAttachMoney className="mr-1 h-6 w-6 text-navy-900 dark:text-white" />
            <span className="text-sm font-medium text-navy-900">
              14-Days money back
            </span>
          </div>
          <div className="mb-5 flex items-center">
            <MdLock className="  mr-1 h-6 w-6 text-navy-900 dark:text-white" />
            <span className="text-sm font-medium text-navy-900">
              Secured AES-256 Encrypted payments powered by Stripe:
            </span>
          </div>
          <div className="mb-5 flex items-center">
            <FaCcVisa className="mr-2.5 h-[30px] w-[30px] text-navy-900 dark:text-white" />
            <FaCcMastercard className="mr-2.5 h-[30px] w-[30px] text-navy-900 dark:text-white" />
            <FaCcPaypal className="mr-2.5 h-[30px] w-[30px] text-navy-900 dark:text-white" />
            <FaCcApplePay className="mr-2.5 h-[30px] w-[30px] text-navy-900 dark:text-white" />
            <FaCcAmex className="h-[30px] w-[30px] text-navy-900 dark:text-white" />
          </div>
        </div>
      </InnerContent>
      <Faq />
      <FooterWebsite />
    </div>
  );
}
