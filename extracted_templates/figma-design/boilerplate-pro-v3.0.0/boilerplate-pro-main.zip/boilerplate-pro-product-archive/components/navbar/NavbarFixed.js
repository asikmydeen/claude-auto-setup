/* eslint-disable */
'use client';

// Chakra Imports
import logo from '/public/logo-horizon-boilerplate.png';
import { useSupabase } from '@/app/supabase-provider';
import { Menu, MenuButton, MenuItem, MenuList } from '@chakra-ui/menu';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';
import { IoIosStar, IoMdTrophy } from 'react-icons/io';
import { IoMenuOutline } from 'react-icons/io5';
import { MdChevronRight, MdPrivacyTip } from 'react-icons/md'; 
import Link from 'next/link';

export default function AdminNavbar(props) {
  const { supabase } = useSupabase();
  const router = useRouter();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    window.addEventListener('scroll', changeNavbar);

    return () => {
      window.removeEventListener('scroll', changeNavbar);
    };
  });
  function refresh() {
    router.refresh();
  }
  const { secondary, message, session } = props;

  const changeNavbar = () => {
    if (window.scrollY > 1) {
      setScrolled(true);
    } else {
      setScrolled(false);
    }
  };
  return (
    <div
      className={`fixed left-[50%] top-0 z-[200] mx-auto flex w-full translate-x-[-50%] translate-y-0 flex-col items-center border-gray-300 bg-white leading-[25.6px] shadow-[45px_76px_113px_7px_rgba(112,_144,_176,_0.08)] dark:border-white dark:text-white xl:justify-center`}
    >
      <div className="hidden w-full justify-center bg-[#F3F5FA] lg:flex">
        <div className="flex w-[calc(100vw_-_4%)] justify-center gap-[40px] py-3 sm:px-[15px] md:w-[calc(100vw_-_4%)] md:px-2.5 lg:w-[100vw] lg:px-3 xl:w-[calc(100vw_-_250px)] 2xl:w-[1200px]">
          <div className="flex flex-row items-center">
            <MdPrivacyTip className="mr-1.5 h-3 w-3 text-brand-500" />
            <p className="h-full text-xs font-medium text-gray-500">
              Founded in EU. We respect your privacy.
            </p>
          </div>
          <div className="flex flex-row items-center">
            <IoIosStar className="mr-[1px] h-3 w-3 text-brand-500" />
            <IoIosStar className="mr-[1px] h-3 w-3 text-brand-500" />
            <IoIosStar className="mr-[1px] h-3 w-3 text-brand-500" />
            <IoIosStar className="mr-[1px] h-3 w-3 text-brand-500" />
            <IoIosStar className="mr-[4px] h-3 w-3 text-brand-500" />
            <p className="h-full text-xs font-medium text-gray-500">
              Loved by 80,000+ users worldwide
            </p>
          </div>
          <div className="flex flex-row items-center">
            <IoMdTrophy className="mr-1.5 h-3 w-3 text-brand-500" />
            <p
              className="h-full text-xs font-medium text-gray-500"
              fontSize="xs"
              fontWeight="500"
              h="100%"
              color="gray.500"
            >
              #1 NextJS boilerplate & admin template
            </p>
          </div>
        </div>
      </div>

      {/* Misc */}

      <div className="mb-0 flex w-[calc(100vw_-_4%)] flex-row items-center justify-between gap-[40px] py-5 sm:px-[15px] md:w-[calc(100vw_-_4%)] md:px-2.5 lg:w-[100vw] lg:px-3 xl:w-[calc(100vw_-_250px)] xl:pl-3 2xl:w-[1200px]">
        <Link className="flex items-center justify-center" href="/">
          <Image
            width="38"
            height="38"
            alt="Horizon UI Boilerplate logo"
            src={logo.src}
          />
          <h5 className="ms-2 text-base font-extrabold leading-5 text-navy-900">
            Horizon UI Boilerplate
          </h5>
        </Link>
        <div className="flex">
          <Link
            className="my-auto mr-[30px] hidden text-sm font-medium leading-[0px] text-gray-600 lg:block"
            href="/dashboard/main"
          >
            Dashboard
          </Link>
          <Link
            className="my-auto mr-[30px] hidden text-sm font-medium leading-[0px] text-gray-600 lg:block"
            href="/dashboard/signin"
          >
            Generator
          </Link>
          <Link
            className="my-auto mr-[30px] hidden text-sm font-medium leading-[0px] text-gray-600 lg:block"
            href="/#features"
          >
            Features
          </Link>
          <Link
            className="my-auto mr-[30px] hidden text-sm font-medium leading-[0px] text-gray-600 lg:block"
            href="/pricing"
          >
            Pricing
          </Link>
          <Link
            className="my-auto mr-[30px] hidden text-sm font-medium leading-[0px] text-gray-600 lg:block"
            href="#faqs"
          >
            FAQs
          </Link>
          <Menu>
            <MenuButton
              display={{ base: 'block', xl: 'none' }}
              p="0px !important"
              maxH="20px"
              maxW="20px"
              alignContent="end"
            >
              <IoMenuOutline className="block h-5 w-5 cursor-pointer text-navy-900 dark:border-white dark:text-white lg:hidden" />
            </MenuButton>
            <MenuList
              className="bg-white dark:bg-navy-800"
              p="0px"
              mt="10px"
              borderRadius="10px"
              border="1px solid"
              borderColor="#CBD5E0"
            >
              <div className="flex flex-col p-2.5">
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                >
                  <Link
                    className="text-md my-auto mr-[30px] font-medium text-gray-600"
                    href="/dashboard/main"
                  >
                    Dashboard
                  </Link>
                </MenuItem>
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                >
                  <Link
                    className="text-md my-auto mr-[30px] font-medium text-gray-600"
                    href="/dashboard/signin"
                  >
                    Generator
                  </Link>
                </MenuItem>
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                >
                  <Link
                    href="/#features"
                    className="text-md my-auto mr-[30px] font-medium text-gray-600"
                  >
                    Features
                  </Link>
                </MenuItem>
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                >
                  <Link
                    href="/pricing"
                    className="text-md my-auto mr-[30px] font-medium text-gray-600"
                  >
                    Pricing
                  </Link>
                </MenuItem>
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                >
                  <Link
                    href="#faqs"
                    className="text-md my-auto mr-[30px] font-medium text-gray-600"
                  >
                    FAQs
                  </Link>
                </MenuItem>
                <MenuItem
                  _hover={{ bg: 'none' }}
                  _focus={{ bg: 'none' }}
                  borderRadius="8px"
                  px="6px"
                  py="3px"
                  mb="6px"
                >
                  <Link
                    href="/dashboard/signin"
                    className="text-md my-auto mr-[30px] font-semibold text-navy-900"
                  >
                    Login
                  </Link>
                </MenuItem>
                <button className="my-auto rounded-full border-[1px] border-gray-300 bg-[transparent] px-2 py-2 text-sm font-semibold text-navy-900 dark:border-white dark:text-white">
                  <Link
                    className="flex flex-row justify-center"
                    href="/dashboard/signin"
                  >
                    Get started for Free
                    <MdChevronRight className="ml-[5px] mt-[3px] h-4 w-4 " />
                  </Link>
                </button>
              </div>
            </MenuList>
          </Menu>
        </div>
        <div className="hidden lg:flex">
          <Link
            className="my-auto mr-[18px] text-sm font-semibold text-navy-900"
            href="/dashboard/signin"
          >
            Login
          </Link>

          <button className="my-auto flex items-center rounded-full border-[1px] border-gray-300 bg-[transparent] px-2 py-2 text-sm font-semibold text-navy-900">
            <Link href="/dashboard/signin" className="flex">
              Get started for Free
              <MdChevronRight className="ml-[3px] mt-[3px] h-4 w-4 " />
            </Link>
          </button>
        </div>
      </div>
      {secondary ? <p className="text-white">{message}</p> : null}
    </div>
  );
}
