'use client';

import { usePathname, useRouter } from 'next/navigation';
import Dropdown from '@/components/dropdown';
import Image from 'next/image';
import React from 'react';
import { useState, useEffect } from 'react';
import { FiAlignJustify } from 'react-icons/fi';
import { IoMoon, IoSunny } from 'react-icons/io5';
import { MdOutlineLogout, MdHelpOutline } from 'react-icons/md';
import { getRedirectMethod } from '@/utils/auth-helpers/settings';
import { useContext } from 'react';
import { handleRequest } from '@/utils/auth-helpers/client';
import { SignOut } from '@/utils/auth-helpers/server';
import { OpenContext, UserContext } from '@/contexts/layout';
import { useTheme } from 'next-themes';
import Link from 'next/link';

export default function HeaderLinks() {
  const { open, setOpen } = useContext(OpenContext);
  const { theme, setTheme } = useTheme();
  const user = useContext(UserContext);
  // const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const pathName = usePathname(); // Always define at the top
  const router = getRedirectMethod() === 'client' ? useRouter() : null;
  const onOpen = () => {
    setOpen(false);
  };
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null;
  }

  return (
    <div className="relative flex h-[61px] min-w-max max-w-max flex-grow items-center justify-around gap-1 rounded-full bg-white px-2 py-2 pl-3 shadow-xl shadow-shadow-500 dark:!bg-navy-800 dark:shadow-none md:w-[365px] md:flex-grow-0 xl:w-[365px] xl:gap-2">
      <span
        className="flex cursor-pointer text-xl text-gray-600   xl:hidden"
        onClick={onOpen}
      >
        <FiAlignJustify className="h-5 w-5" />
      </span>
      <span
        className="my-auto ms-1 flex cursor-pointer items-center text-xl text-gray-600 dark:text-white"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'light' ? (
          <IoMoon className="h-4 w-4" />
        ) : (
          <IoSunny className="h-4 w-4" />
        )}
      </span>

      {/* start Horizon PRO */}
      <Dropdown
        button={
          <p className="cursor-pointer px-1 xl:px-0">
            <MdHelpOutline className="h-[20px] w-[20px] text-gray-600 dark:text-white" />
          </p>
        }
        classNames={'py-2 top-6 -left-[q50px] md:-left-[230px] w-max'}
        animation="origin-[75%_0%] md:origin-top-right transition-all duration-300 ease-in-out"
      >
        <div className="flex w-[250px] flex-col gap-2 rounded-[14px] bg-white p-4 shadow-xl shadow-shadow-500 dark:!bg-navy-700 dark:text-white dark:shadow-none">
          <Link
            target="blank"
            href="/pricing"
            className="flex h-[44px] w-full min-w-[44px] cursor-pointer items-center rounded-full border-[1px] border-gray-200 bg-transparent text-center text-sm font-medium text-navy-900 duration-100 placeholder:text-gray-500 hover:bg-gray-100 focus:bg-gray-200 active:bg-gray-200 dark:border-white/10 dark:bg-navy-800 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/20 dark:active:bg-white/20"
          >
            <p className="mx-auto">Pricing Plans</p>
          </Link>
          <a
            target="blank"
            href="mailto:hello@horizon-ui.com"
            className="flex h-[44px] w-full min-w-[44px] cursor-pointer items-center rounded-full border-[1px] border-gray-200 bg-transparent text-center text-sm font-medium text-navy-900 duration-100 placeholder:text-gray-500 hover:bg-gray-100 focus:bg-gray-200 active:bg-gray-200 dark:border-white/10 dark:bg-navy-800 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/20 dark:active:bg-white/20"
          >
            <p className="mx-auto">Help & Support</p>
          </a>
          <Link
            target="blank"
            href="/#faqs"
            className="flex h-[44px] w-full min-w-[44px] cursor-pointer items-center rounded-full border-[1px] border-gray-200 bg-transparent text-center text-sm font-medium text-navy-900 duration-100 placeholder:text-gray-500 hover:bg-gray-100 focus:bg-gray-200 active:bg-gray-200 dark:border-white/10 dark:bg-navy-800 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/20 dark:active:bg-white/20"
          >
            <p className="mx-auto">FAQs & More</p>
          </Link>
        </div>
      </Dropdown>
      <form onSubmit={(e) => handleRequest(e, SignOut, router)}>
        <input type="hidden" name="pathName" value={pathName} />
        <button type="submit">
          <div className="p-0 mt-1.5 cursor-pointer rounded-[8px]">
            <MdOutlineLogout className="h-5 w-5 text-gray-600 dark:text-white" />
          </div>
        </button>
      </form>
      <a className="w-full" href="/dashboard/settings">
        <Image
          width="40"
          height="40"
          className="h-10 min-h-10 w-10 min-w-10 rounded-full"
          src={
            user?.user_metadata.avatar_url
              ? user?.user_metadata.avatar_url
              : 'https://lh3.googleusercontent.com/a/ACg8ocI5LR8r-XbnmYsQ3hq0a_L534cv4P_PTSHQBRQ36zRaTQ=s96-c'
          }
          alt=""
        />
      </a>
    </div>
  );
}
