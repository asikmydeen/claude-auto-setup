'use client';

/* eslint-disable */
// Chakra Imports
import AdminNavbarLinks from './NavbarLinksAdmin';
import NavLink from '@/components/link/NavLink';
import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function AdminNavbar(props: {
  brandText: string;
  [x: string]: any;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [isWindowAvailable, setIsWindowAvailable] = useState(false);

  useEffect(() => {
    setIsWindowAvailable(typeof window !== 'undefined');
  }, []);

  useEffect(() => {
    isWindowAvailable && window.addEventListener('scroll', changeNavbar);

    return () => {
      isWindowAvailable && window.removeEventListener('scroll', changeNavbar);
    };
  });

  const { brandText } = props;
  const changeNavbar = () => {
    if (isWindowAvailable && window.scrollY > 1) {
      setScrolled(true);
    } else {
      setScrolled(false);
    }
  };

  return (
    <nav
      className={`fixed right-3 top-3 z-[0] flex w-[calc(100vw_-_6%)] flex-row flex-wrap items-center justify-between rounded-[14px] bg-white/30 p-2 backdrop-blur-xl transition-all md:right-[30px] md:top-4 md:w-[calc(100vw_-_8%)] lg:w-[calc(100vw_-_6%)] xl:top-[20px] xl:w-[calc(100vw_-_350px)] 2xl:w-[calc(100vw_-_365px)] dark:bg-[#0b14374d]`}
    >
      <div className="ml-[6px]">
        <div className="mb-2 h-6  pt-1 md:w-[224px]">
          <Link
            className="text-xs font-normal text-navy-900 hover:underline dark:text-white dark:hover:text-white"
            href=" "
          >
            Pages
            <span className="mx-1 text-xs text-navy-900 hover:text-navy-900 dark:text-white">
              {' '}
              /{' '}
            </span>
          </Link>
          <NavLink
            className="text-xs font-normal capitalize text-navy-900 hover:underline dark:text-white dark:hover:text-white"
            href="#"
          >
            {brandText}
          </NavLink>
        </div>
        <p className="shrink text-lg capitalize text-navy-900 md:text-[33px] dark:text-white">
          <NavLink
            href="#"
            className="font-bold capitalize hover:text-navy-900 dark:hover:text-white"
          >
            {brandText}
          </NavLink>
        </p>
      </div>
      <div className="w-[154px] min-w-max md:ml-auto md:w-[unset]">
        <AdminNavbarLinks />
      </div>
    </nav>
  );
}
