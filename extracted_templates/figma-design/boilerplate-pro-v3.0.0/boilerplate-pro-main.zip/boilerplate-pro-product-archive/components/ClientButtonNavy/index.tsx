'use client';

import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function ClientButtonNavy(props: {
  text: string;
  onClick?: any;
}) {
  const { text, onClick } = props;

  return (
    <button
      onClick={onClick ? onClick : null}
      className="mx-auto flex h-[54px] w-full items-center justify-center rounded-full bg-boilerplateNavy px-4 py-5 text-sm font-medium text-white duration-[0.2s] hover:shadow-[0px_11px_24px_-13px_rgba(10,_8,_38,_0.50)] active:shadow-[0px_21px_34px_-13px_rgba(10,_8,_38,_0.50)]"
    >
      {text}
      <MdChevronRight className="mt-0.5 h-4 w-4" />
    </button>
  );
}
