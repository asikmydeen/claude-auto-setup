import Footer from '@/components/footer/FooterAdmin';
import Navbar from '@/components/navbar/NavbarAdmin';
import { routes } from '@/components/routes';
import Sidebar from '@/components/sidebar/Sidebar';
import { Database } from '@/types_db';
import { getActiveRoute } from '@/utils/navigation';
import { User } from '@supabase/supabase-js';
import { usePathname } from 'next/navigation';
import React from 'react';

import {
  PlanContext,
  OpenContext,
  ProductsContext,
  SubscriptionContext,
  UserContext,
  UserDetailsContext
} from '@/contexts/layout';

type Subscription = Database['public']['Tables']['subscriptions']['Row'];
type Product = Database['public']['Tables']['products']['Row'];
type Price = Database['public']['Tables']['prices']['Row'];
interface ProductWithPrices extends Product {
  prices: Price[];
}
interface PriceWithProduct extends Price {
  products: Product | null;
}
interface SubscriptionWithProduct extends Subscription {
  prices: PriceWithProduct | null;
}
interface Props {
  children: React.ReactNode;
  title: string;
  description: string;
  user: User | null | undefined;
  products: ProductWithPrices[];
  subscription: SubscriptionWithProduct | null;
  userDetails: { [x: string]: any } | null;
}

const DashboardLayout: React.FC<Props> = (props: Props) => {
  const pathname = usePathname();
  const [open, setOpen] = React.useState(false);
  const [plan, setPlan] = React.useState({
    product: 'prod_QfhYC6AAtI5IKW',
    price: 'price_1PoM9GDWNoHJSR0zmwpicH8y'
  });

  return (
    <UserContext.Provider value={props.user}>
      <UserDetailsContext.Provider value={props.user}>
        <OpenContext.Provider value={{ open, setOpen }}>
          <PlanContext.Provider value={{ plan, setPlan }}>
            <ProductsContext.Provider value={props.products}>
              <SubscriptionContext.Provider value={props.subscription}>
                <div className="flex h-full w-full bg-white dark:bg-background-900">
                  <Sidebar routes={routes} />
                  <div className="h-full w-full dark:bg-navy-900">
                    <main
                      className={`mx-2.5 flex-none transition-all md:pr-2 xl:ml-[313px] dark:bg-navy-900`}
                    >
                      <div className="mx-auto min-h-screen p-2 !pt-[90px] md:p-2 md:!pt-[118px]">
                        {props.children}
                      </div>
                      <Navbar
                        userDetails={props.userDetails}
                        brandText={getActiveRoute(routes, pathname)}
                      />
                      <div className="p-3">
                        <Footer />
                      </div>
                    </main>
                  </div>
                </div>
              </SubscriptionContext.Provider>
            </ProductsContext.Provider>
          </PlanContext.Provider>
        </OpenContext.Provider>
      </UserDetailsContext.Provider>
    </UserContext.Provider>
  );
};

export default DashboardLayout;
