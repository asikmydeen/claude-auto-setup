/*eslint-disable*/
'use client';

import horizonuilogo from '@/public/horizonuilogo.png';
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';

export function FooterWebsite() {
  return (
    <div className="relative z-[3] flex flex-col items-center justify-between bg-white px-5 pb-[50px] xl:px-0">
      <div className="mb-0 mt-0 flex h-[1px] w-full max-w-[1170px] bg-gray-200 md:mt-[100px] lg:mt-0" />
      <div className="mx-auto mt-[50px] flex w-full max-w-full flex-col justify-between lg:flex-row xl:w-[1170px] xl:max-w-[1170px]">
        <div className="my-auto mb-5 max-w-full lg:mb-0 lg:max-w-max xl:pl-0">
          <Link
            className="mx-auto flex max-w-[217px] items-center lg:mx-[unset]"
            href="/"
          >
            <Image
              width="38"
              height="38"
              alt="Horizon UI Boilerplate logo"
              src="/logo-horizon-boilerplate.png"
            />
            <h5 className="ms-2 text-base font-extrabold leading-5 text-navy-900">
              Horizon UI Boilerplate
            </h5>
          </Link>
        </div>
        <div className="flex w-full flex-col items-center justify-center text-center md:flex-row xl:w-[unset]">
          <div className="mx-auto mb-5 mt-5 flex flex-col items-center justify-center lg:mb-[unset] lg:mr-0 lg:items-end lg:justify-end">
            <div className="my-auto flex flex-col md:flex-row">
              <Link
                target="_blank"
                className="mb-5 mr-0 text-sm font-medium text-gray-600 md:mb-0 md:mr-10"
                href="/pricing"
              >
                Pricing
              </Link>
              <a
                target="_blank"
                href="mailto:hello@horizon-ui.com"
                className="mb-5 mr-0 text-sm font-medium text-gray-600 md:mb-0 md:mr-10"
              >
                Account
              </a>
              <a
                target="_blank"
                href="https://horizon-ui.notion.site/Refund-Policy-1b0983287b92486cb6b18071b2343ac9"
                className="mb-5 mr-0 text-sm font-medium text-gray-600 md:mb-0 md:mr-10"
              >
                Refund Policy
              </a>
              <a
                target="_blank"
                href="https://horizon-ui.notion.site/Privacy-Policy-c22ff04f55474ae3b35ec45feca62bad"
                className="mb-5 mr-0 text-sm font-medium text-gray-600 md:mb-0 md:mr-10"
              >
                Privacy Policy
              </a>
              <a
                target="_blank"
                href="https://horizon-ui.notion.site/Terms-Conditions-c671e573673746e19d2fc3e4cba0c161"
                className="text-sm font-medium text-gray-600"
              >
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="flex w-full max-w-[1170px] px-2.5 md:px-[100px]">
        <p className="mb-10 mt-10 text-center text-sm font-medium leading-[180%] text-gray-600">
          <span className="font-bold">Use it with caution:</span> This tool can
          be helpful, but it is not a substitute for your own knowledge and
          understanding. Make sure to use it as a supplement to your own
          research and writing, rather than relying on it exclusively (you can
          use this on your AI startup website).
        </p>
      </div>
    </div>
  );
}
