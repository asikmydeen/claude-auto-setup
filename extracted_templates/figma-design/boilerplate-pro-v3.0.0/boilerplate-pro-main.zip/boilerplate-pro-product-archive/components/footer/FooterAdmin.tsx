'use client';

/*eslint-disable*/

export default function Footer() {
  return (
    <div className="flex w-full flex-col items-center justify-between px-1 pb-8 pt-3 lg:px-8 xl:flex-row">
      <p className="mb-4 text-center text-sm font-medium text-gray-500 sm:!mb-0 md:text-lg dark:text-gray-400">
        <span className="mb-4 text-center text-sm text-gray-500 sm:!mb-0 md:text-base dark:text-gray-400">
          {/* ©{new Date().getFullYear()} Horizon UI. All Rights Re served. */}
        </span>
      </p>
      <div>
        <ul className="flex flex-wrap items-center gap-3 sm:flex-nowrap md:gap-10">
          <li>
            <a
              target="blank"
              href="mailto:hello@simmmple.com"
              className="text-base font-medium text-gray-500 hover:text-gray-500 dark:text-gray-400"
            >
              Support
            </a>
          </li>
          <li>
            <a
              target="blank"
              href="https://horizon-ui.com/"
              className="text-base font-medium text-gray-500 hover:text-gray-500 dark:text-gray-400"
            >
              Homepage
            </a>
          </li>
          <li>
            <a
              target="blank"
              href="https://horizon-ui.com/boilerplate"
              className="text-base font-medium text-gray-500 hover:text-gray-500 dark:text-gray-400"
            >
              Boilerplate
            </a>
          </li>
          <li>
            <a
              target="blank"
              href="https://blog.horizon-ui.com/"
              className="text-base font-medium text-gray-500 hover:text-gray-500 dark:text-gray-400"
            >
              Blog
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
}
