'use client';

import Footer from '@/components/footer/FooterAuthDefault';
import Link from 'next/link';
import { PropsWithChildren } from 'react';
import { FaChevronLeft } from 'react-icons/fa';

interface DefaultAuthLayoutProps extends PropsWithChildren {
  children: JSX.Element;
  illustrationBackground: string;
  viewProp: any;
}

export default function DefaultAuthLayout(props: DefaultAuthLayoutProps) {
  const { children, illustrationBackground } = props;
  return (
    <div className="relative h-max dark:bg-navy-900">
      <div className="mx-auto flex w-full flex-col justify-center px-5 pt-0 md:h-[unset] md:max-w-[66%] lg:h-[100vh] lg:max-w-[66%] lg:px-6 xl:pl-0 ">
        <Link
          className="mt-10 w-fit md:mb-[150px] mb-[30px] lg:mb-[120px]"
          href="/"
        >
          <div className="flex w-fit items-center lg:pl-0 lg:pt-0 xl:pt-0">
            <FaChevronLeft className="mr-3 h-[13px] w-[8px] text-gray-500" />
            <p className="ml-0 text-sm text-gray-500">Back to the website</p>
          </div>
        </Link>
        {children}
        <div className="absolute right-0 hidden h-full min-h-[100vh] xl:block xl:w-[50vw] 2xl:w-[44vw]">
          <div
            className="absolute flex h-full w-full items-end justify-center bg-cover"
            style={{ backgroundImage: `url(${illustrationBackground})` }}
          />
        </div>
        <Footer />
      </div>
    </div>
  );
}
