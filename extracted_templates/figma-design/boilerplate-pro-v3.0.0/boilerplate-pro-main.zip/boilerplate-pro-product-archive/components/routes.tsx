// Auth Imports
import { IRoute } from '@/types/types';
import {
  MdHome,
  MdAssistant,
  MdWorkspacePremium,
  MdOutlineManageAccounts,
  MdCreditCard,
  MdOutlineDescription,
  MdAutoAwesome,
} from 'react-icons/md';
import { PiCurrencyCircleDollarBold } from 'react-icons/pi';

export const routes: IRoute[] = [
  {
    name: 'Main Dashboard',
    path: '/dashboard/main',
    icon: <MdHome className="-mt-[7px] h-5 w-5 text-inherit" />,
    collapse: false,
  },
  {
    name: 'AI Pages',
    path: '/ai-pages',
    icon: <MdWorkspacePremium className="-mt-[7px] h-5 w-5 text-inherit" />,
    collapse: true,
    items: [
      {
        name: 'AI Generator',
        path: '/dashboard/ai-generator',
        collapse: false,
      },
      {
        name: 'AI Assistant',
        path: '/dashboard/ai-assistant',
        collapse: false,
      },
      {
        name: 'AI Chat',
        path: '/dashboard/ai-chat',
        collapse: false,
      },
    ],
  },
  // {
  //   name: 'AI Generator',
  //   path: '/dashboard/ai-generator',
  //   icon: <MdWorkspacePremium className="-mt-[7px] h-5 w-5 text-inherit" />,
  //   collapse: false,
  // },
  // {
  //   name: 'AI Assistant',
  //   path: '/dashboard/ai-assistant',
  //   icon: <MdAssistant className="-mt-[7px] h-5 w-5 text-inherit" />,
  //   collapse: false,
  // },
  // {
  //   name: 'AI Chat',
  //   path: '/dashboard/ai-chat',
  //   icon: <MdAutoAwesome className="-mt-[7px] h-5 w-5 text-inherit" />,
  //   collapse: false,
  // },
  {
    name: 'Users List',
    path: '/dashboard/users-list',
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="-mt-[7px] h-5 w-5 text-[inherit]"
        height="24"
        viewBox="0 -960 960 960"
        width="24"
      >
        <path
          fill="currentColor"
          d="M640-400q-50 0-85-35t-35-85q0-50 35-85t85-35q50 0 85 35t35 85q0 50-35 85t-85 35ZM400-160v-76q0-21 10-40t28-30q45-27 95.5-40.5T640-360q56 0 106.5 13.5T842-306q18 11 28 30t10 40v76H400Zm86-80h308q-35-20-74-30t-80-10q-41 0-80 10t-74 30Zm154-240q17 0 28.5-11.5T680-520q0-17-11.5-28.5T640-560q-17 0-28.5 11.5T600-520q0 17 11.5 28.5T640-480Zm0-40Zm0 280ZM120-400v-80h320v80H120Zm0-320v-80h480v80H120Zm324 160H120v-80h360q-14 17-22.5 37T444-560Z"
        ></path>
      </svg>
    ),
    collapse: false,
  },
  {
    name: 'Profile Settings',
    path: '/dashboard/settings',
    icon: (
      <MdOutlineManageAccounts className="-mt-[7px] h-5 w-5 text-inherit" />
    ),
    collapse: false,
  },
  {
    name: 'Subscription',
    path: '/dashboard/subscription',
    icon: <MdCreditCard className="-mt-[7px] h-5 w-5 text-inherit" />,
    collapse: false,
  },
  {
    name: 'Landing Page',
    path: '/home',
    icon: <MdOutlineDescription className="-mt-[7px] h-5 w-5 text-inherit" />,
    collapse: false,
  },
  {
    name: 'Pricing Page',
    path: '/pricing',
    icon: (
      <PiCurrencyCircleDollarBold className="-mt-[7px] h-5 w-5 text-inherit" />
    ),
    collapse: false,
  },
];
