import { IoIosStar } from 'react-icons/io';

export default function Ratings(props: {
  dark?: boolean;
  stats: string;
  stars?: 1 | 2 | 3 | 4 | 5;
  rating: string | number;
}) {
  const { rating, stats, stars, dark } = props;
  return (
    <div className="flex flex-col items-center justify-center">
      <p
        className={`mb-2.5 mt-3 self-center font-medium  ${
          dark ? 'text-white' : 'text-navy-900'
        } lg:mt-10`}
      >
        {stats}
      </p>
      {stars === 1 ? (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`mr-2 h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      ) : stars === 2 ? (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`mr-2 h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      ) : stars === 3 ? (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar
            className={`h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <IoIosStar
            className={`mr-2 h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      ) : stars === 4 ? (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar
            className={`mr-2 h-[22px] w-[22px] ${
              dark ? 'text-white/30' : 'text-gray-200'
            }`}
          />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      ) : stars === 5 ? (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`mr-2 h-[22px] w-[22px] text-[#F6AD55]`} />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      ) : (
        <div className="flex items-center justify-center md:justify-start">
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`h-[22px] w-[22px] text-[#F6AD55]`} />
          <IoIosStar className={`mr-2 h-[22px] w-[22px] text-[#F6AD55]`} />
          <p
            className={`my-0.5 text-lg font-bold ${
              dark ? 'text-white' : 'text-navy-900'
            }`}
          >
            {rating}
          </p>
        </div>
      )}
    </div>
  );
}
