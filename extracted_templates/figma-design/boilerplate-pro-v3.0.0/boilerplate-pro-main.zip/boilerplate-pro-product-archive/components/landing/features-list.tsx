// eslint-disable
import nextjs from '@/public/img/hero/nextjs.png';
import openai from '@/public/img/hero/openai.png';
import stripe from '@/public/img/hero/stripe.png';
import supabase from '@/public/img/hero/supabase.png';
import tailwind from '@/public/img/hero/tailwind.png';
import userauth from '@/public/img/hero/user-auth.png';
import Image from 'next/image';

export default function FeaturesList() {
  return (
    <div className="mx-auto mt-[100px] flex w-[1170px] max-w-full flex-wrap items-center justify-center gap-5 md:flex-row xl:mt-[140px] xl:flex-nowrap">
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={nextjs}
        />
        <p className="text-center font-bold text-navy-900">NextJS 14</p>
      </div>
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={stripe}
        />
        <p className="text-center font-bold text-navy-900">Stripe</p>
      </div>
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={supabase}
        />
        <p className="text-center font-bold text-navy-900">Supabase</p>
      </div>
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={tailwind}
        />
        <p className="text-center font-bold text-navy-900">Tailwind CSS</p>
      </div>
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={openai}
        />
        <p className="text-center font-bold text-navy-900">AI Integration</p>
      </div>
      <div className="flex h-[150px] w-[150px] flex-col items-center justify-center rounded-[14px] border-[1px] border-gray-200">
        <Image
          width={100}
          height={100}
          alt=""
          className="mb-2.5 w-[50px] rounded-[12px]"
          src={userauth}
        />
        <p className="text-center font-bold text-navy-900">User Auth</p>
      </div>
    </div>
  );
}
