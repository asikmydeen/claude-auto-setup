// eslint-disable
export default function Newsletter() {
  return (
    <div className="mx-auto mb-[60px] flex max-w-full flex-col">
      <h1 className="mb-5 text-center text-[30px]  font-extrabold text-navy-900">
        Join our newsletter
      </h1>
      <p className="mb-[30px] px-2.5 text-center text-[15px] font-normal text-gray-600 md:px-0 md:text-lg">
        By subscribing, you&apos;ll be the first to know about the latest news
        and updates.
      </p>
      <form
        id="form-fbcaaaec-e795-4419-b112-06934fd0051d"
        action="https://api.encharge.io/v1/forms/fbcaaaec-e795-4419-b112-06934fd0051d/submission/plain"
        method="POST"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexWrap: 'wrap'
        }}
      >
        <div className="sc-jzJRlG kfekry">
          <div className="encharge-form-group sc-jTzLTM frRvjZ form-group">
            <input
              className="encharge-form-input sc-kAzzGY kTMZCx form-control mb-0 mr-[14px] h-full w-[96%] max-w-full rounded-[70px] border-[1px] border-gray-200 bg-white px-5 py-[15px] font-medium text-navy-900 !outline-none placeholder:text-gray-500 focus:placeholder:border-gray-200 md:w-[420px] dark:border-white/20 dark:bg-transparent dark:text-white/60 focus:placeholder:dark:border-white/20"
              placeholder="Enter your email*"
              name="email"
              id="31b6ea2a-d9c7-4b42-9a01-7677838f07e9"
              type="email"
            />
          </div>
        </div>
        <div className="sc-cSHVUG ebRkVm">
          <button
            type="submit"
            className="encharge-form-submit-button sc-gZMcBi ejYzxT btn btn-primary mb-5 flex h-[58px] w-full items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-4 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:mb-0 md:w-[150px] "
          >
            Subscribe
          </button>
        </div>
      </form>
    </div>
  );
}
