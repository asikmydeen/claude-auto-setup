/*eslint-disable*/

import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel
} from '@chakra-ui/accordion';
import Link from 'next/link';

export default function Home() {
  return (
    <div
      className="w-full bg-[linear-gradient(180deg,_#F8FAFC_0%,_rgba(255,_255,_255,_0)_47.33%)] bg-cover px-5 pt-[90px] md:px-0 md:pt-[100px] xl:pt-[140px]"
      id="faqs"
    >
      <div className="mx-auto mb-10 flex max-w-[90%] flex-col items-center justify-center lg:max-w-[62%]">
        <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base">
          FREQUENTLY ASKED QUESTIONS
        </h6>
        <h1 className="mx-auto mb-5 text-center text-[30px] font-extrabold text-navy-900 md:text-[38px]">
          Frequently asked questions
        </h1>
        <p className="mx-auto mb-[30px] max-w-full text-center font-normal leading-[24px] text-gray-600 md:max-w-[80%] md:leading-[30px] xl:text-lg 2xl:max-w-[66%] 3xl:max-w-[56%]">
          Looking for something else? Chat with us via{' '}
          <a className="underline" href="mailto:hello@horizon-ui.com">
            hello@horizon-ui.com
          </a>{' '}
          and we will try our best to help you with your questions!
        </p>
      </div>
      <div className="mx-auto mb-[120px] w-full max-w-full md:max-w-[80%] lg:max-w-[860px]">
        <Accordion allowMultiple>
          <AccordionItem borderTop="0px solid">
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  What is Horizon UI Boilerplate?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  Is Horizon UI Boilerplate Free?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
                <p className="text-base font-normal text-gray-600">
                  You can learn more on our{' '}
                  <Link href="/pricing">
                    <span className="font-bold text-[#422afb]">
                      Pricing Page.
                    </span>
                  </Link>{' '}
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  How does Horizon UI Boilerplate work?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <p className="flex text-left">
                  How can I use Horizon UI Boilerplate?
                </p>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  Is Horizon UI Boilerplate suitable for all academic levels?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  Can I trust the quality of the content generated by Horizon UI
                  Boilerplate?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h3>
              <AccordionButton
                py="25px"
                _hover={{ bg: 'none' }}
                fontSize="md"
                letterSpacing="0px"
                fontWeight={'700'}
                className="text-navy-900"
                _active={{ boxShadow: 'none' }}
                _focus={{ boxShadow: 'none' }}
              >
                <span className="flex text-left">
                  Is the content generated by Horizon UI Boilerplate
                  plagiarism-free?
                </span>
                <AccordionIcon ml="auto" />
              </AccordionButton>
            </h3>
            <AccordionPanel pb={4}>
              <div className="flex flex-col gap-10">
                <p className="text-base font-normal text-gray-600">
                  This is an awesome example of how you can use our accordion
                  component for your FAQs section to provide clear, concise
                  answers while maintaining a clean and engaging user interface.
                  The intuitive design allows users to easily navigate through
                  common questions, expanding each section to find detailed
                  information without overwhelming them with text. It's an ideal
                  way to streamline your website's content and enhance user
                  experience, ensuring that visitors have quick access to the
                  answers they need.
                </p>
              </div>
            </AccordionPanel>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}
