import InnerContent from '@/components/layout/innerContent';
import image from '@/public/img/features/feature-two.png';
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function FeatureTwo() {
  return (
    <div className="relative flex w-full flex-col overflow-hidden bg-cover">
      <InnerContent>
        <div className="flex max-w-[1170px] flex-col-reverse items-center justify-between gap-[70px] px-5 md:px-10 lg:flex-row lg:items-start xl:px-0">
          <Image
            src={image.src}
            width={1150}
            height={1150}
            alt=""
            className="mt-5 w-full md:mt-[50px] lg:mt-0 lg:w-[415px] xl:w-[575px]"
          />
          <div className="my-auto flex max-w-full flex-col items-center lg:items-start">
            <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base lg:text-left">
              EXCLUSIVE PRO FEATURE
            </h6>
            <h1 className="mb-5 w-full max-w-full text-center text-[28px]  font-extrabold leading-[40px] text-navy-900 md:w-[70%] md:max-w-[unset] md:text-[36px] md:leading-[50px] lg:w-full lg:text-left xl:text-[42px] xl:leading-[52px]">
              Advanced Platform for your Startup Web App
            </h1>
            <p className="mb-[30px] w-full text-center text-base font-normal leading-[24px] text-gray-600 md:px-14 md:leading-[30px] lg:w-[97%] lg:px-0 lg:text-left">
              Horizon UI Boilerplate comes with a premium pack that includes all
              the necessary resources to launch your startup, like the fully
              coded web app pages, landing, database, payments and so on.
            </p>
            <div className="flex flex-col items-center justify-center md:mb-0 md:flex-row lg:mb-[30px] lg:justify-start">
              <Link className="mr-0 md:mr-[14px]" href="/dashboard/main">
                <button className="mb-5 flex w-[335px] items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-4 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:mb-0 md:w-[230px] ">
                  Go to the dashboard
                  <MdChevronRight className="mt-0.5 h-4 w-4" />
                </button>
              </Link>
              <Link href="/pricing">
                <button className="mb-5 flex w-[335px] items-center justify-center rounded-full border-[1px] border-gray-200 bg-[unset] bg-gradient-to-tr px-4 py-4 text-sm font-medium text-navy-900 transition duration-200 hover:bg-gray-200 md:mb-0 md:w-[190px] ">
                  See pricing plans
                  <MdChevronRight className="mt-0.5 h-4 w-4" />
                </button>
              </Link>
            </div>
          </div>
        </div>
      </InnerContent>
    </div>
  );
}
