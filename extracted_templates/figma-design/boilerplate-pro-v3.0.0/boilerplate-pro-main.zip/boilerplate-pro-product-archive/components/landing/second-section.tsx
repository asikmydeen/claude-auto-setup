// eslint-disabled
import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function SecondSection() {
  return (
    <div
      className="relative z-[2] flex w-full flex-col items-center bg-cover pt-[90px] md:pt-[140px] xl:pt-[180px]"
      id="features"
    >
      <div className="flex max-w-[1170px] flex-col items-center justify-center px-0 md:px-10 xl:px-0">
        <div className="flex w-[stretch] flex-col">
          <div className="mx-auto flex flex-col items-center text-center">
            <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base dark:text-white">
              GENERATE ESSAYS IN SECONDS
            </h6>
            <h1 className="mx-auto mb-5 text-center text-[30px]  font-extrabold leading-[38px] text-navy-900 md:mb-[30px] md:text-[48px] md:leading-[60px] xl:text-[58px] xl:leading-[70px]">
              How it works?
            </h1>
          </div>
        </div>
        <div className="flex w-[86%] max-w-full flex-col items-center justify-center pt-10 md:w-[76%] md:pt-[60px] lg:w-[100%] lg:flex-row">
          <div className="lg-0 mb-[50px] mr-0 flex flex-col lg:mb-0 lg:mr-8">
            <h5 className="mb-3 text-center text-base  font-extrabold text-navy-900 md:text-left xl:text-xl">
              Step 1: This is an example
            </h5>
            <p className="w-[98%] text-center text-base font-normal leading-8 text-gray-600 md:text-left md:text-base md:leading-[30px]">
              This is where your first step paragraph goes. For the moment, this
              is just an example to see what it will look like.
            </p>
          </div>
          <div className="mr-0 hidden min-h-[38px] min-w-[38px] items-center justify-center rounded-[50px] bg-white shadow-[0px_10.83px_28px_-2px_rgba(203,_213,_224,_0.79)] lg:mr-8 lg:flex">
            <MdChevronRight className="h-6 w-6 bg-transparent text-[#7B5AFF]" />
          </div>
          <div className="lg-0 mb-[50px] mr-0 flex flex-col lg:mb-0 lg:mr-8">
            <h5 className="mb-3 text-center text-base  font-extrabold text-navy-900 md:text-left xl:text-xl">
              Step 2: This is another example
            </h5>
            <p className="w-[98%] text-center text-base font-normal leading-7 text-gray-600 md:text-left md:text-base md:leading-[30px]">
              This is where your second step paragraph goes. For the moment,
              this is just an example to see what it will look like.
            </p>
          </div>
          <div className="mr-0 hidden min-h-[38px] min-w-[38px] items-center justify-center rounded-[50px] bg-white shadow-[0px_10.83px_28px_-2px_rgba(203,_213,_224,_0.79)] lg:mr-8 lg:flex">
            <MdChevronRight className="h-6 w-6 bg-transparent text-[#7B5AFF]" />
          </div>
          <div className="lg-0 mb-[50px] mr-0 flex flex-col lg:mb-0">
            <h5 className="mb-3 text-center text-base  font-extrabold text-navy-900 md:text-left xl:text-xl">
              Step 3: This is an example too
            </h5>
            <p className="w-[98%] text-center text-base font-normal leading-7 text-gray-600 md:text-left md:text-base md:leading-[30px]">
              This is where your third step paragraph goes. For the moment, this
              is just an example to see what it will look like.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
