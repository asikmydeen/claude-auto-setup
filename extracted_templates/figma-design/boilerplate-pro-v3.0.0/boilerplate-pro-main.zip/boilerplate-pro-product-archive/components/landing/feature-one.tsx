import InnerContent from '@/components/layout/innerContent';
import image from '@/public/img/features/feature-one.png';
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function FeatureOne() {
  return (
    <div className="relative flex w-full flex-col overflow-hidden bg-cover pb-[100px] pt-[100px] md:pb-[140px] md:pt-[140px]">
      <InnerContent>
        <div className="justfify-between flex max-w-[1170px] flex-col items-center gap-[50px] px-5 md:px-10 lg:flex-row lg:items-start xl:px-0">
          <div className="my-auto flex max-w-full flex-col items-center lg:items-start">
            <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base lg:text-left">
              YOUR STARTUP FEATURES
            </h6>
            <h1 className="mb-5 w-full max-w-full text-center text-[28px]  font-extrabold leading-[40px] text-navy-900 md:w-[70%] md:max-w-[unset] md:text-[36px] md:leading-[50px] lg:w-[90%] lg:text-left xl:text-[42px] xl:leading-[52px]">
              Ready to use Web App for your Startup project
            </h1>
            <p className="mb-[30px] w-full text-center text-base font-normal leading-[24px] text-gray-600 md:w-[80%] md:leading-[30px] lg:w-[100%] lg:text-left">
              It’s so easy to beat your endless procrastination when you have
              all the necessary resources to get that project done and start to
              generate your startup’s first dollar in just a few days.
            </p>
            <div className="mb-0 flex w-full flex-col items-center justify-center md:flex-row lg:mb-[30px] lg:justify-start">
              <Link className="mr-0 md:mr-[14px]" href="/dashboard/main">
                <button className="mb-5 flex w-[335px] items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-4 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:mb-0 md:w-[230px] ">
                  Go to the dashboard
                  <MdChevronRight className="mt-0.5 h-4 w-4" />
                </button>
              </Link>
              <a href="/pricing">
                <button className="mb-5 flex w-[335px] items-center justify-center rounded-full border-[1px] border-gray-200 bg-[unset] bg-gradient-to-tr px-4 py-4 text-sm font-medium text-navy-900 transition duration-200 hover:bg-gray-200 md:mb-0 md:w-[190px] ">
                  See pricing plans
                  <MdChevronRight className="mt-0.5 h-4 w-4" />
                </button>
              </a>
            </div>
          </div>
          <Image
            src={image.src}
            width={1150}
            height={1150}
            alt=""
            className="mt-5 w-full md:mt-[50px] lg:mt-0 lg:w-[415px] xl:w-[575px]"
          />
        </div>
      </InnerContent>
    </div>
  );
}
