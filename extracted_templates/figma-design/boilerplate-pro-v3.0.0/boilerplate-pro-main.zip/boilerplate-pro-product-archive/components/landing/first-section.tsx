import dashboard from '@/public/img/first-section/dashboard-world-greatest-section.png';
import left from '@/public/img/first-section/left-image-worlds-greatest.png';
import right from '@/public/img/first-section/right-image-worlds-greatest.png';
import Image from 'next/image';
import React from 'react';

export default function FirstSection() {
  return (
    <div className="relative z-[2] flex w-full flex-col bg-cover pt-[90px] md:pt-[100px] xl:pt-[140px]">
      <div className="flex max-w-[unset] flex-col px-5 md:px-10 xl:px-0">
        <div className="flex w-[stretch] flex-col">
          <div className="mx-auto flex flex-col items-center text-center">
            <h6 className="mb-2.5 w-full text-center text-xs font-bold tracking-widest text-brand-500 md:text-base dark:text-white">
              BEST AI NEXTJS BOILERPLATE
            </h6>
            <h1 className="mx-auto mb-5 w-full text-center text-[30px]  font-extrabold leading-[38px] text-navy-900 md:mb-[30px] md:w-[80%] md:text-[48px] md:leading-[60px] lg:w-[60%] xl:w-[50%] xl:text-[58px] xl:leading-[70px]">
              Your All-in-One
              <br />
              Startup Boilerplate
            </h1>
            <p className="w-[96%] text-base font-normal leading-8 text-gray-600 md:w-[80%] md:text-base md:leading-[30px] lg:w-[80%] xl:w-[54%] xl:text-lg xl:leading-[32px] 2xl:text-lg 2xl:leading-[32px]">
              Tap into the power of Artificial Intelligence for your startup
              needs with Horizon UI Boilerplate, the most complex NextJS
              boilerplate to launch your web app project in just a few moments.
            </p>
          </div>
        </div>
        <div className="relative mx-auto mt-4 flex max-w-[335px] justify-center rounded-lg md:mt-[10px] md:max-w-[1170px] lg:mt-[40px]">
          <Image
            src={dashboard.src}
            width={1150}
            height={1150}
            alt=""
            className="mt-5 max-h-max w-full max-w-[335px] rounded-lg shadow-[0px_26.83487px_155.64224px_-46.15597px_#CBD5E0] md:mt-[50px] md:max-w-[1170px] lg:mt-0"
          />
          <Image
            src={left.src}
            width={1150}
            height={1150}
            alt=""
            className="absolute left-[1px] top-[33px] w-[62px] rounded-lg shadow-[0px_10.1683px_61.0098px_rgba(0,_0,_0,_0.05)] md:left-[5px] md:top-[75px] md:w-[122px] lg:left-[10px] lg:top-[36px] lg:w-[168px] xl:-left-[20px] xl:top-[45px] xl:w-[224px]"
          />
          <Image
            src={right.src}
            width={1150}
            height={1150}
            alt=""
            className="absolute -right-[16px] top-[48px] w-[286px] rounded-lg md:-right-[30px] md:top-[105px] md:w-[592px] lg:-right-[44px] lg:top-[80px] lg:w-[806px] xl:-right-[53px] xl:top-[98px] xl:w-[1026px]"
          />
        </div>
      </div>
    </div>
  );
}
