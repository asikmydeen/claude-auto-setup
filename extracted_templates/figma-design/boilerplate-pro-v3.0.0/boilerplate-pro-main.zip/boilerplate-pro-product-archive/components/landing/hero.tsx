import Ratings from '@/components/testimonials/Ratings';
import imageLeft from '@/public/img/hero/left-image.png';
import imageRight from '@/public/img/hero/right-image.png';
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function hero() {
  return (
    <div
      className="rounded-5 relative mx-auto mt-[90px] flex w-[96vw] flex-col content-center 
     items-center rounded-[20px] bg-[radial-gradient(98.96%_75.83%_at_50%_0%,_#948FE8_0%,_#363285_22.92%,_#110D5B_42.71%,_#050327_88.54%)] 
     md:mt-[90px]
     md:rounded-[30px] lg:mt-[123px] 2xl:w-[94vw]"
    >
      <div className="flex w-full">
        <div className="mb-0 flex w-[stretch] max-w-full flex-row content-center items-center justify-between py-[60px] md:mb-[30px] md:py-[100px] lg:pb-[160px] lg:pt-[190px] 3xl:pb-[150px] 3xl:pt-[200px]">
          <Image
            src={imageLeft.src}
            width={2340}
            height={1150}
            alt=""
            className="absolute left-0 hidden w-[90%] md:w-full lg:w-[30%] xl:block"
          />
          <div className="mx-auto flex flex-col text-center">
            <h1 className="z-[100] mx-auto mb-8 max-w-[94%] bg-[linear-gradient(180deg,_#FFF_66.39%,_rgba(255,_255,_255,_0.50)_105.56%)] bg-clip-text text-3xl font-bold leading-[36px] text-transparent md:max-w-[70%] md:text-[50px] md:leading-[60px] lg:max-w-[70%] lg:text-[50px] lg:leading-[68px] xl:max-w-[50%] 2xl:text-[50px] 2xl:leading-[68px] 3xl:text-[58px]">
              Launch your startup project 10X faster in a few moments
            </h1>
            <h5 className="mb-10 w-[84%] self-center text-sm font-normal leading-6 text-white md:mb-10 md:w-[82%] md:text-base md:leading-[30px] lg:w-[62%] xl:w-[44%] xl:text-lg xl:leading-[32px] 2xl:w-[44%] 2xl:text-lg 2xl:leading-[32px]">
              Create a professional website for your startup in no time with
              Horizon UI Boilerplate. Our comprehensive template will help you
              launch your project 10X faster, leaving you more time to focus on
              your business.
            </h5>
            <Link
              className="w-[300px] self-center md:w-[340px]"
              href="/dashboard/main"
            >
              <button className="mb-6 flex w-[300px] items-center justify-center rounded-full bg-gradient-to-tr from-brandGradient-500 to-brandGradient-400 px-4 py-5 text-sm font-medium text-white transition duration-200 hover:shadow-[0px_21px_27px_-10px_rgba(96,_60,_255,_0.48)_!important] md:mb-0 md:w-[340px] ">
                Go to the dashboard
                <MdChevronRight className="mt-0.5 h-4 w-4" />
              </button>
            </Link>
            <Ratings
              dark
              stats="Used by 80,000+ users monthly"
              rating="4.9"
              stars={5}
            />
          </div>
          <Image
            src={imageRight.src}
            width={2340}
            height={1150}
            alt=""
            className="absolute right-0 hidden w-[90%] md:w-full lg:w-[30%] xl:block"
          />
        </div>
      </div>
    </div>
  );
}
