'use client';

import React from 'react';
import { MdChevronRight } from 'react-icons/md';

export default function ClientButton(props: { text: string; onClick?: any }) {
  const { text, onClick } = props;

  return (
    <button
      className="mx-auto flex h-[54px] w-full items-center justify-center rounded-full bg-white/30 px-4 py-5 text-sm font-medium text-white duration-[0.2s] hover:bg-white/40 active:bg-white/50 "
      onClick={onClick ? onClick : null}
    >
      {text}
      <MdChevronRight className="mt-0.5 h-4 w-4" />
    </button>
  );
}
